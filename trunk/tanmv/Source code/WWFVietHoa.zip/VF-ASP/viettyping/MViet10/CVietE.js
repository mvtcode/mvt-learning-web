﻿//f:processLet
function pL(mve){
S=document.selection.createRange()		
if(!ready||S.text.length!=0||BoDauMV=="")return;
S3=S.duplicate(),iD=-1,kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
S3.moveStart("word",-1);t=S3.text
if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
if(t.charAt(t.length-1)==' '){if(key=='.'||key=='?'){S.moveStart("character",-1);S.text="";return}else return}
if(t.length>0){if(iD>-1&&iD<12){VanDisplay(3,key,iD);if(eT==0)mve.returnValue=false;return}
else if(kL=='o'||kL=='n'){VanDisplay(4,'',-1);if(eT==0)mve.returnValue=false}}
}
//f:VanDisplay
function VanDisplay(n,value,ord){S=document.selection.createRange()
S3=S.duplicate();S3.moveStart("character",-1);
if(S3.text.length==0||" ,.;-='\"?<>/\\{}()*&1234567890".indexOf(S3.text)>-1)eT=1
else{
S2=S.duplicate();
S2.moveStart("word",-1);tI=S2.text; if(n==4)tI+=key  
var tO=VB(tI,n,value,ord);if(tO!='')S2.text=tO
}}

/*
// REMOVE the rest if you DON't NEED iframe
*/
function mvEvent(id){
var oB= frames[id];
 oB.document.designMode="On"
 oB.document.attachEvent("onkeypress", function(){ pLF(oB) ;})
 oB.document.attachEvent("onclick",function(){ mvHTML = true;})	
 oB.document.attachEvent("onkeydown",function(){ mvHTML = true; if(oB.event.keyCode==123) MVietOnOffButton(); })//1
} 

function pLF(oB){ 
var evf=oB.event
var kv=evf.keyCode;
var key=String.fromCharCode(kv)
if (kv==32|| kv==191) return;
if (MVOff) return;	     	 
var S=oB.document.selection.createRange();

if(S.text.length!=0||BoDauMV=="")return;

var S3=S.duplicate(),iD=-1,kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
S3.moveStart("word",-1);t=S3.text;
if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
if(t.charAt(t.length-1)==' '){if(key=='.'||key=='?'){S.moveStart("character",-1);S.text="";return}else return}
if(t.length>0){if(iD>-1&&iD<12){VanDisplayF(oB,3,key,iD,"");
if(eT==0)evf.returnValue=false;
return}
else if(kL=='o'||kL=='n'){VanDisplayF(oB,4,'',-1,key);
if(eT==0)evf.returnValue=false
}}
}
//f:VanDisplay
function VanDisplayF(oB,n,value,ord,key){
S=oB.document.selection.createRange()
S3=S.duplicate();S3.moveStart("character",-1);
if(S3.text.length==0||" ,.;-='\"?<>/\\{}()*&1234567890".indexOf(S3.text)>-1)eT=1
else{
S2=S.duplicate();
S2.moveStart("word",-1);tI=S2.text; if(n==4)tI+=key  
var tO=VB(tI,n,value,ord);if(tO!='')S2.text=tO
}}
