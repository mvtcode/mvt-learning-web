﻿/* logo: CViet 8/20/03: mViet10 by SPham [mviet@socal.rr.com] 
* Copyright (c) 1999, 2000-2005 MDSS. Inc All Rights Reserved.
* This code is free on noncommercial. 
* This copyright notice must remain intact within this code.
*/
//Modified by Betterboy_st
//=================================================================
 var nIframe="message|htmlbox".split("|");
 for (var i=0; i<nIframe.length; i++) {
 if(document.getElementById(nIframe[i])) mvEvent(document.getElementById(nIframe[i]).id)
 } 
function mVietTypeMode(id){
var DauMau = new Array(6);
DauMau[0] = "|||||||||||";
DauMau[1] = "\'1|`2|?3/|~4|5.|^6|+*7|(8|d9-|";
DauMau[2] = "\'1s|`2f|?3r|~4x|5.j|^6aeo|+*7w|(<8w|d9-|";
DauMau[3] = "\'|`|?/|~|.|^6|+=|(9|d|";
DauMau[4] = "1|2|3|4|5|6|7|8|9|";
DauMau[5] = "s|f|r|x|j|aeo|w|w|d|";
BoDauMV = DauMau[id];
}
//==================================================================
//2:declaration
var noMViet='email|emailconfirm|BoDau|'
var BoDauMV="\'1s|`2f|?3r|~4x|j.5|^6aeo|+*7=w|(8w|d9|"
var MVOff=false,eT=0,i,j,s,S,S2,S3,u,v,tI,tO,vt=1
var f=document.all?true:false
var D="|dz|ch|c|b|d|đ|gh|gi|g|h|kh|k|l|m|ngh|ng|nh|n|ph|qu|r|s|th|tr|t|v|x".split('|')
var C="|ng|nh|ch|c|o|u|i|y|m|n|p|t|a".split('|')//vt17 the^m a
var A="oa|oá|oà|oả|oã|oạ*oă|oắ|oằ|oẳ|oẵ|oặ*uâ|uấ|uầ|uẩ|uẫ|uậ*oe|oé|oè|oẻ|oẽ|oẹ*uyê|uyế|uyề|uyể|uyễ|uyệ*uye|uyé|uyè|uyẻ|uyẽ|uyẹ*uy|uý|uỳ|uỷ|uỹ|uỵ*uê|uế|uề|uể|uễ|uệ*ue|ué|uè|uẻ|uẽ|uẹ*ia|ía|ìa|ỉa|ĩa|ịa*iê|iế|iề|iể|iễ|iệ*ie|ié|iè|iẻ|iẽ|iẹ*yê|yế|yề|yể|yễ|yệ*ye|yé|yè|yẻ|yẽ|yẹ*ua|úa|ùa|ủa|ũa|ụa*uô|uố|uồ|uổ|uỗ|uộ*ưa|ứa|ừa|ửa|ữa|ựa*ươ|ướ|ườ|ưở|ưỡ|ượ*ưo|ứo|ừo|ửo|ữo|ựo*uơ|uớ|uờ|uở|uỡ|uợ*uo|uó|uò|uỏ|uõ|uọ*ă|ắ|ằ|ẳ|ẵ|ặ*â|ấ|ầ|ẩ|ẫ|ậ*a|á|à|ả|ã|ạ*ê|ế|ề|ể|ễ|ệ*iu|íu|ìu|ỉu|ĩu|ịu*ư|ứ|ừ|ử|ữ|ự*u|ú|ù|ủ|ũ|ụ*ô|ố|ồ|ổ|ỗ|ộ*ơ|ớ|ờ|ở|ỡ|ợ*e|é|è|ẻ|ẽ|ẹ*o|ó|ò|ỏ|õ|ọ*i|í|ì|ỉ|ĩ|ị*y|ý|ỳ|ỷ|ỹ|ỵ*ơ|ớ|ờ|ở|ỡ|ợ".split('*');
for(i=0;i<A.length; i++) A[i]=A[i].split('|');

var oB= document.getElementsByTagName("textarea"); evB(oB);
oB= document.getElementsByTagName("input"); evB(oB);

function evB(oB){
for( var i=0; i<oB.length ;i++)
if (noMViet.indexOf(oB.name) == -1){
    if(f){oB[i].onkeydown=mvKD;oB[i].onkeypress=mvKP;}
    else{oB[i].addEventListener("keydown", mvKD, false);oB[i].addEventListener("keypress", mvKP, false);}
   }
}    
//event
	
function mvKD(e){
elm= f?event.srcElement:e.target;key=f?event.keyCode:(e&&e.which)?e.which:0
V(elm);if(ready&&key==123)MVietOnOffButton();
}	
function V(x){ready=x.type=='textarea'||(x.type=='text'&&noMViet.indexOf(x.name+"|")==-1)}

function mvKP(e){
if(MVOff) return;
key=f?String.fromCharCode(event.keyCode):String.fromCharCode(e.which)
f?pL(event):pLZ(e) 
}
//===
function VB(tI,n,value,ord){	
var tO=''
if(tI.length>0){tIL=tI.toLowerCase();s=Parsing(tIL,ord);
if(ck(tIL,s,n,ord)==0){tO=ModifyWord(s,n,value,ord);if(tO!=null){tO=match(tI,tO);if(n==4)eT=0}}
}
return tO}
//f:Parsing
function Parsing(W,ord){
if(W=="gi")return "g|32,0,i||";else if(W=="gin")return "g|32,0,i|n|"	
var L0="",L1="",L2="",xD=-1

for(i=1;i<D.length;i++)if(W.indexOf(D[i])==0){xD=i;break}
if(xD!=-1){L0=D[xD];W=W.substring(D[xD].length)}
if(W.length!=0)
if (W=='oa'&&vt==1&&ord<6&&ord>0) return L0+"|"+"31,0,o"+"|a|" 
else if(W=='uy'&&vt==1&&ord<6&&ord>0){return L0+"|"+"27,0,u"+"|y|"}	
else {u=-1;v=-1
for(i=0;i<A.length;i++){for(j=0;j<A[i].length;j++){var iT=W.indexOf(A[i][j])	
if(iT==0){u=i;v=j;if(iT>0){if(L0=="")L0=W.substring(0,iT);W=W.substring(iT)}break}}
if(u!=-1)break}if(u!=-1){var base=A[u][0];
W=W.substring(base.length);
if(base=='o'&&vt==1&&W.charAt(0)=='a' && W.length>1) {u=0;W=W.substring(1);base='oa'}
L1=u+","+v+","+base}
if(W.length!=0){xD=-1
for(i=1;i<C.length;i++)if(W.indexOf(C[i])==0){xD=i;break}if(xD!=-1){L2=W.substring(0,C[xD].length);W=W.substring(L2.length)}
}}return L0+"|"+L1+"|"+L2+"|"+W	}

//f:ModifyWord
function ModifyWord(s,n,value,ord){eT=0;if(n==4)eT=1
var nW="";s=s.split('|'),c=s[1].split(','),z=parseInt(c[0]),y=c[2]
var c1=parseInt(c[1])
if(s[1]=='') {c=null; y=null}
switch(n){case 0:s[0]=value;break
case 3:var id2="aeiouy".indexOf(value);if(id2>-1)
if(y==null){ord=-1;eT=1}
else if(y.indexOf(value)==-1)if((id2==0&&y.indexOf('ă')==-1&&y.indexOf('â')==-1)
||(id2==1&&y.indexOf('ê')==-1)||(id2==3&&y.indexOf('ơ')==-1&&y.indexOf('ô')==-1)
||(id2==4&&y.indexOf('ư')==-1)||(id2==2||id2==5)){ord=-1;eT=1}
if(ord==8){if(z==0||z==1||z==2||z==21||z==22||z==23)ord=8;
else if( (z>13&& z<21)||(z>25&&z<30)||z==31||z==33)ord=7
else{ord=-1;eT=1}
}
switch(ord){
case 1:case 2:case 3:case 4:case 5:if(ord==parseInt(c[1])){c[1]=0;eT=1}else c[1]=ord;if(ord==2&&z==19)z=17;break
case 9:if(s[0]=="d")s[0]='đ';else if(s[0]=='đ'){s[0]='d',eT=1}else eT=1;break
case 6:if(z==2){z=14;eT=1}
else if(z==5)z=4;else if(z==7){z=8;eT=1}else if(z==8)z=7
else if(z==10){z=11;eT=1}else if(z==11)z=10
else if(z==12){z=13;eT=1}else if(z==13)z=12;else if(z==14)z=2
else if(z==15){z=20;eT=1}else if(z==17)z=15
else if(z==20)z=15;else if(z==21)z=22
else if(z==22){z=23;eT=1}
else if(z==23)z=22;else if(z==24){z=30;eT=1}
else if(z==28){z=31;eT=1}else if(z==29){z=28;eT=1}
else if(z==30){z=24}else if(z==31){z=28}else if(z==34){z=28;eT=1}
else eT=1
break
case 7:
if(z==14)z=16;	
else if(z==15)z=19;else if(z==17)z=20;
else if(z==18||z==19)z=17;else if(z==16){z=14;eT=1}
else if(z==20){if((s[0]=="th"||s[0]=="qu"||s[0]=="kh")&&s[2].length==0&&(c[1]==3||c[1]==4||c[1]==0))z=19;else z=17}
else if(z==26)z=27;else if(z==27)z=26;else if(z==28)z=29
else if(z==29){z=31;eT=1}else if(z==31)z=29
else if(z==34){z=31;eT=1}
else eT=1
break
case 8:if(z==0)z=1;else if(z==1){z=0;eT=1}else if(z==21){z=23;eT=1}
else if(z==22)z=21;else if(z==23){z=21}else eT=1;break	
}//ord
break
}
//
if(s[0]!='c'&&y=='o'&&s[2]=='o')return null
if(n==4&&s[2].length>0&&(z==18||z==19)){z=17}
	
for(i=0;i<3;i++){if(s[i]!="")if(i!=1)nW+=s[i]
else{u=parseInt(z);v=parseInt(c[1]);if(nW=="qu"&&A[u][v].substring(0,1)=="u")nW="q"

if(nW=="c"&&(A[u][0]=="oa"||A[u][0]=="oă"||A[u][0]=="uâ"||A[u][0]=="oe"))nW="qu"+A[u][v].substring(1)
else if(nW=="r"&&(A[u][0]=="oa"||A[u][0]=="oă"||A[u][0]=="uâ"||A[u][0]=="oe"))nW+=A[u][v].substring(1)
else if(nW=="r"&&(A[u][0]=="uyê"||A[u][0]=="uy"||A[u][0]=="uê"))nW="d"+A[u][v]
else if((nW=="th"||nW=="q"||nW=="kh")&&s[2]==""&&A[u][0]=="ưo")nW+=A[u+1][v]
else nW+=A[u][v]}}return nW}
//f:match
function match(O,N){var r="",l=O.length
if(l==0)r=N
else if(l==1){if(O==O.toUpperCase())r=N.toUpperCase();else r=N}
else{var f=O.charAt(0),fL=O.toLowerCase().charAt(0),s=O.charAt(1),sL=O.toLowerCase().charAt(1)
if(f==fL)r=N;else{if(s==sL)r=N.toUpperCase().charAt(0)+N.substring(1);else r=N.toUpperCase()}
}return r}

//f:check
function ck(tIL,s1,n1,o1){var iR=0

if(tIL.indexOf('ou')>-1) return 35
s1=s1.split("|"),c=s1[1].split(",");

c4= f?s1[3].length>0:s1.length>3  //diff than VBB	
if(c4||(s1[1].length==0&&s1[0]!='d'&&s1[0]!='đ')){iR=34;eT=1
}else if(n1==3&&s1[0].length>0&&s1[2].length>0&&"tcp".indexOf(s1[2].charAt(0))>-1&&(o1==2||o1==3||o1==4)){iR=34;eT=1}
return iR}