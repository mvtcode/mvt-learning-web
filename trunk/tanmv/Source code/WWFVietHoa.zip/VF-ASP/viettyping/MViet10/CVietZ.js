function  pLZ(e){
var elm=e.currentTarget,strOri=key
var ta=elm.value,lastInd =-1,n = ta.length 
var start= elm.selectionStart,end= elm.selectionEnd,t= ta.substring(0,start), dd= ta.substr(end)

if(t.charAt(n-1)==' '){if(key=='.'||key=='?'){elm.value = elm.value.substring(0,n-1);return}else return}
var spr=" '?\"(){}[]<>/-\n\r_" 
for (i=0; i<spr.length; i++) if (t.lastIndexOf(spr.charAt(i))>lastInd) lastInd = t.lastIndexOf(spr.charAt(i))
t=t.substring(lastInd+1)
n = t.length;
start=end-n;

var kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)	
iD=-1;if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
var nMV='';if(t.length>0)if(iD>-1&&iD<12)nMV=VB(t,3,key,iD);else if(kL=='o'||kL=='n')nMV=VB(t+key,4,'',-1) 
if (nMV.length<1)return
else {elm.value= elm.value.substring(0,start) + nMV + elm.value.substr(end)
var caret= elm.value.substring(0,start).length+ nMV.length
elm.setSelectionRange(caret,caret)
if (eT==0) e.preventDefault()
}
}
/*
//REMOVE the rest if you don't need to write in iframe	
*/
//writen by mViet, supported by www.conguan.com
//use iFrame
function mvEvent(id){
var ua = navigator.userAgent.toLowerCase();isGecko = (ua.indexOf("gecko") != -1)
var frameHtml = "<html id='"+id+"' >\n";frameHtml += "<head>\n";
frameHtml += "<style>\n";frameHtml += "body {\n";frameHtml += "	background: #FFFFFF;\n";
frameHtml += "	margin: 0px;\n";frameHtml += "	padding: 0px;\n";
frameHtml += "}\n";frameHtml += "</style>\n";
frameHtml += "</head>\n";frameHtml += "<body>\n";
	//frameHtml += "hello" + "\n";
frameHtml += "</body>\n";frameHtml += "</html>";

var oRTE = document.getElementById(id).contentWindow.document;
oRTE.open();oRTE.write(frameHtml);oRTE.close()
try {if (isGecko) {
oRTE.addEventListener("keypress", kb_handler, true); 
oRTE.addEventListener("keydown", kb_dn, true);
}
} catch (e) {if (isGecko) {setTimeout("mvEvent()", 10);} else {return false;}}
document.getElementById(id).contentDocument.designMode = "on";
document.getElementById(id).focus();	
}
//
function kb_dn(evt) { if(evt.keyCode==123)MVietOnOffButton();}
function kb_handler(evt,rte) { var rte = evt.target.id; mvmoz(evt,rte);}
function mvmoz(evt,rte){
if (evt.keyCode==8|| evt.keyCode==13|| evt.keyCode==37 || evt.keyCode==38|| evt.keyCode==39|| evt.keyCode==40 || evt.charCode==32|| evt.keyCode==191) return;
else if (!MVOff){mvwindow =document.getElementById(rte).contentWindow;
mvbox = document;   
var sel=mvwindow.getSelection(),range = null;

mvwindow.focus()
range = sel ? sel.getRangeAt(0) : mvbox.createRange()
var pos1 = range.startOffset
var node1 = range.endContainer;
var textMV=mvnode(range.cloneContents(), false)
var n=textMV.length
if (n>0) node1.deleteData(pos1, n);
range.setEnd(node1, pos1);
range.setStart(node1, 0);
textMV=mvnode(range.cloneContents(), false)

n = textMV.length
var charCode = textMV.charCodeAt(n-1)

if (charCode ==32 && (evt.charCode==46 ||evt.charCode==63 )) 
  {range.setStart(node1, pos1-1);node1.deleteData(pos1-1, 1); return;} 
key=String.fromCharCode(evt.charCode); 
var spr=" '?\"(){}[]<>/-."
if (charCode ==32||charCode==160||(n>0 && " ,.;-='\"?<>/\\{}()*&1234567890".indexOf(textMV.charAt(n-1))>-1) 
||(n==0 && !evt.shiftKey)) {range.setStart(node1,pos1); return;}
var lastInd = -1 
for (i=0; i<spr.length; i++) if (textMV.lastIndexOf(spr.charAt(i))>lastInd) lastInd = textMV.lastIndexOf(spr.charAt(i))
tI=textMV.substring(lastInd+1);
range.setStart(node1, pos1);  
var kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL);
iD=-1
if(nD>-1){var iT=0
for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}	
if(iD==8&&BoDauMV.indexOf(kL,nD+1)>-1)bt=1;else bt=0
}

if(tI.length>0){var nMV=''
if(iD>-1&&iD<12){nMV=VB(tI,3,key,iD)
if(nMV!=tI && nMV.length>0){
node1.deleteData(lastInd+1, pos1-lastInd-1)
pos1 = range.startOffset
node1.insertData(lastInd+1,nMV)
newLen=nMV.length
range.setEnd(node1,lastInd+1+newLen)
range.setStart(node1,lastInd+1+newLen)
iD=-2 
}
if(eT==0){evt.preventDefault();
/*
if(!daset){
if(Bo3[0].indexOf(kL)>-1)ctDau[0]++
else if(Bo3[1].indexOf(kL)>-1)ctDau[1]++
else if(Bo3[2].indexOf(kL)>-1)ctDau[2]++;
if(ctDau[0]>mct){BoDauMV="'|`|?/|~|.|^6|+*=8|9(|-d|\\|";daset=true}
else if(ctDau[1]>mct){BoDauMV=Bo3[1];daset=true}else if(ctDau[2]>mct){BoDauMV=Bo3[2];daset=true}
if(daset){setMV(BoDauMV,"BoDau");if(document.all)kieugodiv.innerHTML=DisplayBDCN();else document.getElementById('kieugodiv').innerHTML=DisplayBDCN()} 
}
*/
}//=0
return; 
}else if("on".indexOf(kL)>-1)
{tI=tI+key;nMV=VB(tI,4,'',-1)
if(nMV!=tI && nMV.length>0){node1.deleteData(lastInd+1, pos1-lastInd-1);pos1 = range.startOffset;node1.insertData(lastInd+1,nMV);
newLen=nMV.length;range.setEnd(node1,lastInd+1+newLen);range.setStart(node1,lastInd+1+newLen);iD=-2} 
eT=1; if(eT==0){evt.preventDefault();}
}//4
}//1	 
}//MVOff
}

function mvnode(root, toptag)
{var html = "";moz_check = /_moz/i;
switch (root.nodeType)
{case Node.ELEMENT_NODE: case Node.DOCUMENT_FRAGMENT_NODE:
{var closed;
if (toptag){
				closed = !root.hasChildNodes();
				html = '<' + root.tagName.toLowerCase();
				var attr = root.attributes;
				for (i = 0; i < attr.length; ++i)
				{
					var a = attr.item(i);
					if (!a.specified || a.name.match(moz_check) || a.value.match(moz_check))
					{continue;}
					html += " " + a.name.toLowerCase() + '="' + a.value + '"';
				}
				html += closed ? " />" : ">";
			}
			for (var i = root.firstChild; i; i = i.nextSibling)
			{html += mvnode(i, true);}
			if (toptag && !closed)
			{html += "</" + root.tagName.toLowerCase() + ">";}
		}
		break;

		case Node.TEXT_NODE:
		{html = root.data}
		break;
	}
	return html;
}