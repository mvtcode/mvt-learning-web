﻿///Bước1:Sao, dán, và cất(save)dưới tên CViet.js (dạng UTF-8) vô trong: ./mvVBB/
//01: update error detection
/* logo: CViet 8/20/03: mViet10 by SPham [mviet@socal.rr.com]
* Copyright (c) 1999, 2000-2005 MDSS. Inc All Rights Reserved.
* This code is free on noncommercial.
* This copyright notice must remain intact within this code.
*/
//Modified by Betterboy_st
//=================================================================
 var nIframe="message|htmlbox".split("|");
 for (var i=0; i<nIframe.length; i++) {
 if(document.getElementById(nIframe[i])) mvEvent(document.getElementById(nIframe[i]).id)
 } 
function mVietTypeMode(id){
var DauMau = new Array(6);
DauMau[0] = "|||||||||||";
DauMau[1] = "\'1|`2|?3/|~4|5.|^6|+*7|(8|d9-|";
DauMau[2] = "\'1s|`2f|?3r|~4x|5.j|^6aeo|+*7w|(<8w|d9-|";
DauMau[3] = "\'|`|?/|~|.|^6|+=|(9|d|";
DauMau[4] = "1|2|3|4|5|6|7|8|9|";
DauMau[5] = "s|f|r|x|j|aeo|w|w|d|";
BoDauMV = DauMau[id];
}
//==================================================================
var noMViet='email|BoDau'
var MVhnVal=31,iHN=new Array(1,1,1,1,1),hnNew=0
var BoDauMV='\'1s|`2f|?3r|~4x|5.j|^6aeo|+*7=w|(8w|d9-|'
var MVOff=false,eT=0,i,j,s,S,S2,S3,u,v,tI,tO,vt=1,currElm=null,mvHTML=false;
var Fonoff=123,Ftcc=121;var f=document.all?true:false
var D0='dz|f|mv|',D1='ch|c|b|d|đ|gh|gi|g|h|kh|k|l|m|ngh|ng|nh|n|ph|qu|r|s|th|tr|t|v|x',D2='|w|p'
var D=(D0+D1+D2).split('|')
var C='|ng|nh|ch|c|o|u|i|y|m|n|p|t|a'.split('|')
var A='oă|oắ|oằ|oẳ|oẵ|oặ*oa|oá|oà|oả|oã|oạ*uâ|uấ|uầ|uẩ|uẫ|uậ*ua|úa|ùa|ủa|ũa|ụa*oe|oé|oè|oẻ|oẽ|oẹ*uyê|uyế|uyề|uyể|uyễ|uyệ*uye|uyé|uyè|uyẻ|uyẽ|uyẹ*uy|uý|uỳ|uỷ|uỹ|uỵ*uê|uế|uề|uể|uễ|uệ*ue|ué|uè|uẻ|uẽ|uẹ*iê|iế|iề|iể|iễ|iệ*ie|ié|iè|iẻ|iẽ|iẹ*yê|yế|yề|yể|yễ|yệ*ye|yé|yè|yẻ|yẽ|yẹ*ưa|ứa|ừa|ửa|ữa|ựa*ươ|ướ|ườ|ưở|ưỡ|ượ*ưo|ứo|ừo|ửo|ữo|ựo*uơ|uớ|uờ|uở|uỡ|uợ*uô|uố|uồ|uổ|uỗ|uộ*uo|uó|uò|uỏ|uõ|uọ*ă|ắ|ằ|ẳ|ẵ|ặ*â|ấ|ầ|ẩ|ẫ|ậ*a|á|à|ả|ã|ạ*ư|ứ|ừ|ử|ữ|ự*u|ú|ù|ủ|ũ|ụ*ê|ế|ề|ể|ễ|ệ*e|é|è|ẻ|ẽ|ẹ*oo|oó|oò|oỏ|oõ|oọ*ơ|ớ|ờ|ở|ỡ|ợ*ô|ố|ồ|ổ|ỗ|ộ*o|ó|ò|ỏ|õ|ọ*i|í|ì|ỉ|ĩ|ị*y|ý|ỳ|ỷ|ỹ|ỵ*ơ|ớ|ờ|ở|ỡ|ợ'.split('*');
for(i=0;i<A.length; i++) A[i]=A[i].split('|');
var oB= document.getElementsByTagName('textarea'); evB(oB,0)
oB= document.getElementsByTagName('input'); evB(oB,1)
function evB(oB,mtype){if (mtype==0) for( var i=0; i<oB.length ;i++) evBX(oB[i]);
else for( var i=0; i<oB.length ;i++) if((noMViet.indexOf(oB[i].name)==-1||!oB[i].name) && oB[i].type=='text') evBX(oB[i])}
function evBX(X) {if(f){X.onclick=mvCK;X.onkeydown=mvKD; X.onkeypress=mvKP}else{X.addEventListener('keydown', mvKD, false);X.addEventListener('keypress', mvKP, false);}}
function mvCK(e){elm= f?event.srcElement:e.target;key=f?event.keyCode:(e&&e.which)?e.which:0;V(elm)}

function mvKD(e){mvCK(e)
if(key==Fonoff)MVietOnOffButton()
else if(key==Ftcc && document.getElementById('showpopup')){
if (document.getElementById('mvframe')){if(f)showpopup.innerHTML='';else document.getElementById('showpopup').innerHTML=''; }
else {showbox();if(f)showpopup.innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2;else document.getElementById('showpopup').innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2;}
elm.focus()}}
function V(x){ready=x.type=='textarea'||x.type=='text';if (ready) {currElm = x;mvHTML=false}}
function mvKP(e){if(MVOff) return;key=f?String.fromCharCode(event.keyCode):String.fromCharCode(e.which);f?pL(event):pLZ(e)}
var B3=new Array('\'|`|?|~|.|^|+*|(|d|', 's|f|r|x|j|aeo|w|w|d|', '1|2|3|4|5|6|7|8|9|','\'1|`2|?/3|~4|.5j|^6|+*=87|89(|-d|');
var cD=new Array(0,0,0,0),ds=false,mct=5
function sD(kL){if(!ds) {for(i=0;i<4;i++) if(B3[i].indexOf(kL)>-1)cD[i]++
for(i=0;i<4;i++)if(cD[i]>mct){BoDauMV=B3[i]; setMV(BoDauMV,'BoDau') 
if (document.getElementById('showpopup')){showbox();if(f)showpopup.innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2;else document.getElementById('showpopup').innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2}else if (document.getElementById('showBD'))DisplayTCC()
ds=true;break}}}

function VB(tI,n,value,ord){
var tO='';if(tI.length>0){tIL=tI.toLowerCase();
s=Parsing(tIL,ord)
if(ck(tIL,s,n,ord)==0){
tO=ModifyWord(s,n,value,ord);if(tO!=null){tO=match(tI,tO);if(n==4)eT=0}
}
}return tO}
function Parsing(W,ord){
if(W=='gi')return 'g|31,0,i||';else if(W=='gin')return 'g|31,0,i|n|'
var L0='',L1='',L2='',xD=-1
for(i=0;i<D.length;i++)if(W.indexOf(D[i])==0){xD=i;break}
if(xD!=-1){L0=D[xD];W=W.substring(D[xD].length)}
if(W.length!=0)
if (W=='oa'&&vt==1&&ord<6&&ord>0) return L0+'|'+'30,0,o'+'|a|'
else if(W=='uy'&&vt==1&&ord<6&&ord>0){return L0+'|'+'24,0,u'+'|y|'}
else {u=-1;v=-1
for(i=0;i<A.length;i++){for(j=0;j<A[i].length;j++){var iT=W.indexOf(A[i][j])
if(iT==0){u=i;v=j;if(iT>0){if(L0=='')L0=W.substring(0,iT);W=W.substring(iT)}break}}
if(u!=-1)break}if(u!=-1){var base=A[u][0]
W=W.substring(base.length)
if(base=='o'&&vt==1&&W.charAt(0)=='a' && W.length>1) {u=0;W=W.substring(1);base='oa'}
L1=u+','+v+','+base}
if(W.length!=0){xD=-1
for(i=1;i<C.length;i++)if(W.indexOf(C[i])==0){xD=i;break}if(xD!=-1){L2=W.substring(0,C[xD].length);W=W.substring(L2.length)}
}}return L0+'|'+L1+'|'+L2+'|'+W	}

function ModifyWord(s,n,value,ord){eT=0;if(n==4)eT=1
var nW='';s=s.split('|'),c=s[1].split(','),z=parseInt(c[0]),y=c[2]
var c1=parseInt(c[1])
if(s[1]=='') {c=null; y=null}
if (n==5){
if (value=='d'){if(s[0]=='d')s[0]='đ';else if(s[0]=='đ'){s[0]='d',eT=1}else eT=1}
else {var L="0ưu|xuu|1êe|xee|2ơo|xôo|xoo|2ăa|xâa|xaa|1oăa|xoaa|1uâa|xuaa|1yêe|xyee|1uyêe|xuyee|1uêe|xuee|1iêe|xiee|1ươo|xưoo|2uơo|xuôo|xuoo|"
var iL=L.indexOf(y+value+'|'); eT=1;if (iL>-1){if(L.charAt(iL-1)=='x') {z--;eT=0} else z=z+parseInt(L.charAt(iL-1));} 
}
}
else 
switch(n){
case 0:s[0]=value;break
case 3:var id2='aeiouy'.indexOf(value);if(id2>-1)
if(y==null){ord=-1;eT=1}
else if(y.indexOf(value)==-1)if((id2==0&&y.indexOf('ă')==-1&&y.indexOf('â')==-1)
||(id2==1&&y.indexOf('ê')==-1)||(id2==3&&y.indexOf('ơ')==-1&&y.indexOf('ô')==-1)
||(id2==4&&y.indexOf('ư')==-1)||(id2==2||id2==5)){ord=-1;eT=1}
if(ord==8){if(z==0||z==1||z==2||z==20||z==21||z==22)ord=8;
else if(z==3||(z>13&& z<20)||z==21|(z>22&&z<25)||z==30||z==32)ord=7 
else{ord=-1;eT=1}
}
switch(ord){
case 1:case 2:case 3:case 4:case 5:if(ord==parseInt(c[1])){c[1]=0;eT=1}else c[1]=ord;if(ord==2&&z==17)z=15;break
case 9:if(s[0]=='d')s[0]='đ';else if(s[0]=='đ'){s[0]='d',eT=1}else eT=1;break
case 6:
if(z==2){z=3;eT=1}
else if(z==6)z=5;else if(z==8){z=9;eT=1}else if(z==9)z=8
else if(z==10){z=11;eT=1}else if(z==11)z=10
else if(z==12){z=13;eT=1}else if(z==13)z=12;else if(z==3)z=2
else if(z==18){z=19;eT=1}
else if(z==15||z==17||z==19)z=18 
else if(z==20)z=21
else if(z==21){z=22;eT=1}
else if(z==22)z=21;else if(z==25){z=26;eT=1}
else if(z==29){z=30;eT=1}else if(z==28)z=29
else if(z==26){z=25}else if(z==30){z=29}else if(z==33){z=29;eT=1}
else eT=1
break
case 7:
if(z==3)z=14
else if(z==18)z=17;else if(z==15)z=19
else if(z==16||z==17)z=15;else if(z==14){z=3;eT=1}
else if(z==19){if((s[0]=='th'||s[0]=='qu'||s[0]=='kh')&&s[2].length==0&&(c[1]==3||c[1]==4||c[1]==0))z=17;else z=15}
else if(z==23){z=24;eT=1}else if(z==24)z=23;else if(z==29)z=28
else if(z==28){z=30;eT=1}else if(z==30)z=28
else if(z==33){z=30;eT=1}
else eT=1
break
case 8:if(z==1)z=0;else if(z==0){z=1;eT=1}else if(z==20){z=22;eT=1}
else if(z==21)z=20;else if(z==22){z=20}else eT=1;break	
}
break
}

if(s[0]!='c'&&y=='o'&&s[2]=='o')return null
if(n==4&&s[2].length>0&&(z==16||z==17)){z=15}
var ctmv="",RedO='<font color=red>',RedC='</font>',BL='<font color=blue>|</font>'
for(i=0;i<3;i++){if(s[i]!='') 
	if(i!=1) {nW+=s[i]; ctmv+=s[i]}
    else{u=parseInt(z);v=parseInt(c[1]);
ctmv+=BL
if(nW=='qu'&&A[u][v].substring(0,1)=='u') {nW='q'; ctmv=nW+BL}
else {
if(nW=='c'&&(A[u][0]=='oa'||A[u][0]=='oă'||A[u][0]=='uâ'||A[u][0]=='oe')) {nW='qu'+A[u][v].substring(1); ctmv='qu>'+RedO+A[u][0].substring(1)}
else if(nW=='r'&&(A[u][0]=='oa'||A[u][0]=='oă'||A[u][0]=='uâ'||A[u][0]=='oe')){nW+=A[u][v].substring(1); ctmv+=RedO+A[u][0].substring(1)}
else if(nW=='r'&&(A[u][0]=='uyê'||A[u][0]=='uy'||A[u][0]=='uê')){nW='d'+A[u][v]; ctmv='d'+'>'+RedO+A[u][0]}
else if((nW=='th'||nW=='q'||nW=='kh')&&s[2]==''&&A[u][0]=='ưo'){nW+=A[u+1][v]; ctmv+=RedO+A[u+1][0]}
else {nW+=A[u][v];ctmv+=RedO+A[u][0]}
ctmv+=RedC
if (v>0)ctmv+=','
ctmv+='<font size=-1 color=red><i>'
if (v==1)ctmv+='sắc'; else if (v==2)ctmv+='huyền'; else if (v==3)ctmv+='hỏi';else if (v==4)ctmv+='ngã'; else if (v==5)ctmv+='nặng'; 
ctmv+='</i></font>'+RedC+BL 	
}
}}
if (document.getElementById('ct')) document.getElementById('ct').innerHTML=ctmv; 
return nW}

function match( O, N ){
var r=''; var n= O.length;
if (n==0) r=N;
else if (n==1) {if (O==O.toUpperCase()) r=N.toUpperCase(); else r=N;}
else if (n!=N.length){
if (O.charAt(0)==O.toLowerCase().charAt(0)) r=N
else {if (O.charAt(1)==O.toLowerCase().charAt(1)) r=N.toUpperCase().charAt(0)+N.substring(1)
else r=N.toUpperCase();}
}else for (var i=0; i<n; i++)
if (O.charAt(i)==O.toLowerCase().charAt(i)) r += N.charAt(i);
else r += N.toUpperCase().charAt(i);
return r;
}
function ck(tIL,s,n,o){var iR=0
s=s.split('|'),c=s[1].split(',')
c4= f?s[3].length>0:s.length>3
if(c4||(s[1].length==0&& ((s[0]!='d'&& s[0]!='đ')||(o!=9&&key!='d'&&key!='D')))){iR=33;eT=1 
}else if(n==3&&s[0].length>0&&s[2].length>0&&'tcp'.indexOf(s[2].charAt(0))>-1&&(o==2||o==3||o==4)){iR=34;eT=1}
else { var p=c[2], q=s[2]; var ip="aiouy".indexOf(p), iq="aiouy".indexOf(q);
if (ip>-1 && iq>-1) if ("ai|ao|au|ay|ia|oa|oi|ua|ui|uo|uu|uy|iu|".indexOf(p+q+'|')==-1){iR=34;eT=1} 
}
return iR}

//Add On================================================================
function getcookie(name){var dc = document.cookie,pfix = name + '=';bn = dc.indexOf('; ' + pfix);if (bn == -1) {bn = dc.indexOf(pfix);if (bn != 0) return null} else bn += 2;var ed = dc.indexOf(';', bn);if (ed == -1)ed = dc.length;return unescape(dc.substring(bn + pfix.length, ed));}
function getMV(mvName, mvDef){var t = getcookie(mvName),tp=mvDef; if(t) tp=t; return tp;}
function setMV(mvVal, mvName){document.cookie = mvName+'='+mvVal+'; expires=Monday, 04-Apr-2010 05:00:00 GMT';}
var tBDMV=getMV('BoDau', '')
if (tBDMV!=''){ds=true;BoDauMV=tBDMV;}
var jvmload=false
var pHa='<img src=\''
var pHb=' onClick=\''
var pT='MVietOnOffButton();\' alt=\'F'
var pT1=':  Tắt/Bật mViệt\'>';
var On = pHa+folder+'on.gif\''+pHb+ pT+(Fonoff-111)+pT1
var Off =pHa+folder+'off.gif\''+pHb+ pT+(Fonoff-111)+pT1
var On1 = pHa+'on.gif\''+pHb+'parent.'+pT+(parent.Fonoff-111)+pT1
var Off1 =pHa+'off.gif\''+pHb+'parent.'+pT+(parent.Fonoff-111)+pT1

var tcc=1 //new

var MVOnButton,MVOffButton,OnOff
function MVietOnOffButton (){
if (document.getElementById('MVietOnOff')) {MVOnButton = On;MVOffButton=Off;OnOff = document.getElementById('MVietOnOff')}
else if (document.getElementById('mvframe')){
  MVOnButton = On1; MVOffButton =Off1;
  if(document.all)OnOff = window.mvframe.document.getElementById('MVietOnOff');
  else OnOff=document.getElementById('mvframe').contentDocument.getElementById('MVietOnOff')
} 
if (MVOff) {MVOff=false; if (OnOff!=null) OnOff.innerHTML=MVOffButton;} 
else {MVOff=true; if (OnOff!=null) OnOff.innerHTML=MVOnButton;} 
}
//move 4lines out for multiple uses
var headMV =    '<td align=center class=KhungTitleDau >' + '<SPAN CLASS=TitleDau > ';
var headRedMV = '<td align=center class=KhungTitleDau >' + '<SPAN CLASS=TitleDau > ';
var tailMV = '</SPAN><br><SPAN CLASS=Dau >';
var endMV = '</SPAN></td>';

function DisplayBDCN (){	
var bD = BoDauMV.split('|');
var bDTit= '&nbsp;Sắc&nbsp;|&nbsp;Huyền&nbsp;|&nbsp;Hỏi&nbsp;|&nbsp;Ngã&nbsp;|&nbsp;Nặng&nbsp;|&nbsp;Nón&nbsp;|&nbsp;Móc&nbsp;|&nbsp;Trăng&nbsp;|Gạch'.split('|');
var strBDCN='<table class=KhungDau><tr>';
if(document.getElementById('showBD') || (!document.getElementById('MVietOnOff') && !document.getElementById('showBD'))){
	strBDCN +='<td align=center valign=middle><div id=MVietOnOff >'
	if (MVOff)strBDCN +=MVOnButton; else strBDCN += MVOffButton	
    strBDCN  +='</div></td>';
}
for (var i =0; i< 9; i++){ 
  if (bD[i].length!=0) strBDCN  += headMV+ bDTit[i]+ tailMV+ bD[i]+ endMV; 
}
strBDCN  += headRedMV+'Thay'+ tailMV;
strBDCN  += '<img src=\''+folder+ 'n_pencil.gif\' '
strBDCN  += ' onClick="window.focus(); if(document.all) showBD.innerHTML=Kh3+iFr1+mvKG+iFr2+Kh2; else document.getElementById(\'showBD\').innerHTML=Kh3+iFr1+mvKG+iFr2+Kh2;" '
strBDCN  += ' alt=\'Kiểu Gõ\'  width=12 height=15>' + endMV; 
strBDCN  += headRedMV+ 'Chỉnh'+ tailMV
strBDCN  += '<img src=\''+folder+'n_wand.gif\' onClick="window.focus();checkBDCD(); " alt=\'Dấu Rời\'  width=12 height=15>' + endMV;
strBDCN  += headRedMV+'Dùng'+ tailMV
strBDCN  += '<img src=\''+folder+'huongdan11/1.gif\' onClick="window.open(\''+folder+'huongdan11/hd11.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\'  width=6 height=10>' 
strBDCN  += '<img src=\''+folder+'huongdan11/2.gif\' onClick="window.open(\''+folder+'huongdan11/hd12.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\' width=6 height=10>' 
strBDCN  += '<img src=\''+folder+'huongdan11/3.gif\' onClick="window.open(\''+folder+'huongdan11/hd13.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\' width=6 height=10>' 
strBDCN  += endMV; 

//2nd
strBDCN  += headRedMV+'»'+ tailMV
strBDCN  += "<img src='"+folder+"images/phai.gif' onClick=\"if(document.all) showBD.innerHTML=DisplayBDCN1(); else document.getElementById('showBD').innerHTML=DisplayBDCN1(); tcc=2;\" alt='Dụng Cụ Tiện Ích'  width='8' height='15'>" + endMV; 

strBDCN  += '</tr></table>';
return strBDCN;	
}


function DisplayBDCN1 (){	

var strBDCN=""
var strBDCN='<table class=KhungDau><tr>';

strBDCN+="<td align='center' valign='middle' style='position:relative;top:-1'><div width=30 height=30>"
strBDCN+="<a href= 'JavaScript:onClick=xshowModalDialog(\"" +folder+ "javaCheck.htm\", window, \"dialogWidth:400px; dialogHeight:270px; resizable: no; help: no; status: no; scroll: no; \"); '>"
strBDCN+="<img src='"+folder+"images/n_javaCheck.gif' border='0' alt='Java Check' border='0' width='24' height='23'></a></div>"
strBDCN+="</td>"
//	
strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN+="<img src='"+folder+"images/d_hn.gif' onClick='window.focus(); if (document.all) showBD.innerHTML=Kh3+iFr1+mvHN+iFr2+Kh2; else document.getElementById(\"showBD\").innerHTML=Kh3+iFr1+mvHN0+iFr2+Kh2;'  alt='Hỏi Ngã' width='70' height='23'>"
strBDCN+="</div></td>"
/*
strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN+="<img src='mviet/images/d_tk.gif' onClick='window.focus();kieugodiv.innerHTML=Kh3+iFr1+mvTK+iFr2+Kh2' alt='Tốc ký' width='70' height='23'>"
strBDCN+="</div></td>"

strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN+="<img src='mviet/images/d_tt.gif' onClick='window.focus();if (htmlOn) kieugodiv.innerHTML=Kh3+iFr1+mvTT+iFr2+Kh2; else kieugodiv.innerHTML=Kh3+iFr1+mvTT0+iFr2+Kh2;' alt='Tìm & Thế' width='70' height='23'>"
strBDCN+="</div></td>"
*/
strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN+="<img src='"+folder+"images/d_cm.gif' onClick='window.focus();if(!navigator.javaEnabled()) alert(\"Please download JVM at java.sun.com to use this feature\"); else { if (document.all) showBD.innerHTML=Kh3+iFr1+mvHC+iFr2+Kh2; else document.getElementById(\"showBD\").innerHTML=Kh3+iFr1+mvHC+iFr2+Kh2;} ' alt='Hoán chuyển' width='90' height='23'>"
strBDCN+="</div></td>"
strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN+="<img src='"+folder+"images/d_td.gif' onClick='window.focus();if (document.all) showBD.innerHTML=Kh3+iFr1+mvTD+iFr2+Kh2; else document.getElementById(\"showBD\").innerHTML=Kh3+iFr1+mvTD+iFr2+Kh2;' alt='Từ điển' width='70' height='23'>"
strBDCN+="</div></td>"

strBDCN+="<td align='center' valign='middle'><div style='position:relative;top:-1' width='30' height='30'>"
strBDCN+="<a href= 'JavaScript:onClick=xShowModalDialog(\"http://www.thanhda.com/mviet/dhtml/index2.htm\", this, \"dialogHeight:370px; dialogWidth:250px; dialogTop:200px; dialogLeft:40px; edge:Raised; center:Yes; help:No; resizable:No; status:No;\"); '>"

strBDCN+="<img src='"+folder+"images/s_nt2.gif' border='0' alt='mViệt php(HL)' border='0' width='24' height='23'></a></div>"
strBDCN+="</div></td>"
strBDCN+="<td align='center' valign='middle'><div style='position:relative;top:-1' width='30' height='30'>"
strBDCN+="<a href= 'JavaScript:onClick=xShowModalDialog(\"http://www.conguan.com/portal/shoutbox/index.htm\", this, \"dialogWidth:250px; dialogHeight:370px; resizable: no; help: no; status: no; scroll: no; \"); '>"
strBDCN+="<img src='"+folder+"images/s_nt2.gif' border='0' alt='Công Uẩn' border='0' width='24' height='23'></a></div>"
strBDCN+="</div></td>"

strBDCN+="<td align='center' valign='middle'><div style='position:relative;top:-1' width='30' height='30'>"
strBDCN+="<a href= 'JavaScript:onClick=xShowModalDialog(\"http://213.196.3.135/minhluan/shoutboxmv/\", this, \"dialogWidth:530px; dialogHeight:580px; resizable: yes; help: no; status: no; scroll: yes; \"); '>"
strBDCN+="<img src='"+folder+"images/s_nt2.gif' border='0' alt='mViệt ASP' border='0' width='24' height='23'></a></div>"
strBDCN+="</div></td>"

strBDCN+="<td align='center' valign='middle'><div width='30' height='30'>"
strBDCN+="<a href= 'JavaScript:onClick=xShowModalDialog(\""+folder+"openFile.htm\", window, \"resizable: yes; help: no; status: no; scroll: yes; \");'>"
strBDCN+="<img src='"+folder+"images/n_open.gif' border='0' alt='Mở Bài' border=0 width=24 height=23></a>"
strBDCN+="</div></td>"

strBDCN+="<td align='center' valign='middle'><div width='30' height='30'>"
strBDCN+="<a href= 'JavaScript:onClick=mvsave(htmlwindow.innerHTML);'>"
strBDCN+="<img src='"+folder+"images/n_save.gif' border='0' alt='Save Bài' border='0' width='24' height='23'></a>"
strBDCN+="</div></td>"
	
strBDCN+="<td align=center valign=middle><div width=30 height=30>"
strBDCN  += '<img src=\''+folder+'huongdan11/1.gif\' onClick="window.open(\''+folder+'huongdan11/hd21.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\'  width=6 height=10>'  
strBDCN+="</div></td>"


		
strBDCN  += endMV;

/*hoan Chuyen	
strBDCN  += headMV //+ "<font style='font-size:8pt'>Từ</font>"+ tailMV
strBDCN  += "<select name='MVHoan' style='position:relative;top:-2' class='mvselect'><option value='-1' style='color: blue' selected>Auto</option> <option value='0'>VietNet*</option> <option value='1' style='color: orange'>Unicode</option><option value='2'>VNI</option> <option value='3'>VPS</option><option value='4'>VISCII</option> <option value='5'>TCVN3</option><option value='6'>Uni&#</option> <option value='7'>UTF8-Bal</option><option value='8'>UTF8-Wes</option> <option value='9'>Hex</option></select>"
strBDCN  += "<img src='"+folder+"images/s_cm.gif' border='0' style='position:relative;top:2' onClick='HoanChuyenFn();' alt='Chuyễn Cốt'>"  
strBDCN  += "<select name='MVTarget' style='position:relative;top:-2' class='mvselect'><option value='0'>VietNet*</option><option value='1' selected style='color: orange'>Unicode</option><option value='2'>VNI</option><option value='3'>VPS</option><option value='4'>VISCII</option><option value='5'>TCVN3</option><option value='6'>Uni&#</option><option value='7'>UTF8-Bal</option><option value='8'>UTF8-Wes</option><option value='9'>Hex</option></select>"
strBDCN  += endMV;
*/
//next
strBDCN  += headMV 
strBDCN  += "<img src='"+folder+"images/phai.gif' onClick=\"if(document.all) showBD.innerHTML=DisplayBDCN2(); else document.getElementById('showBD').innerHTML=DisplayBDCN2(); tcc=3; \" alt='Next'  width='8' height='22'>" 
strBDCN  += endMV;

strBDCN+="</tr></table>"
//
return strBDCN;	
}
function DisplayBDCN2 (){	
var strBDCN='<table class=KhungDau><tr>';
strBDCN+="<td align=center valign=middle>"
strBDCN+="<div align=center id=ct></div></td>"			
strBDCN  += endMV;
strBDCN  += headMV 
strBDCN  += "<img src='"+folder+"images/phai.gif' onClick=\"if(document.all) showBD.innerHTML=DisplayBDCN(); else document.getElementById('showBD').innerHTML=DisplayBDCN(); tcc=1; \" alt='Next'  width='8' height='22'>" 
strBDCN  += endMV;

strBDCN  += headMV 
strBDCN  += '<img src=\''+folder+'huongdan11/1.gif\' onClick="window.open(\''+folder+'huongdan11/hd31.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\'  width=6 height=10>' 
//strBDCN  += '<img src=\''+folder+'huongdan11/2.gif\' onClick="window.open(\''+folder+'huongdan11/hd12.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\' width=6 height=10>' 
//strBDCN  += '<img src=\''+folder+'huongdan11/3.gif\' onClick="window.open(\''+folder+'huongdan11/hd13.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\' width=6 height=10>' 
strBDCN  += endMV; 

strBDCN+="</tr></table>"
//
return strBDCN;	
}



function checkBDCD(){
if(!navigator.javaEnabled()) alert('Please download JVM at java.sun.com to use this feature');
else {	
	
	var appmviet='<applet code=VietInterfaceIE5.class  height=1 width=1 NAME=VietInterface ARCHIVE=VT70.jar CODEBASE=./mvVBB/  ALT=\'Your browser understands the applet tag but is not displaying any applet.\' ></applet>'
	if (document.all)jvmdiv.innerHTML = appmviet;
	else document.getElementById('jvmdiv').innerHTML= appmviet;
	jvmload=true

  if (currElm==null) alert('Please hi-light a section to convert');
  else { 
    if (document.all) {
       var src = currElm.document.selection.createRange(); 
       if (src.text.length == 0 ){ 
          if(!mvHTML){ currElm.select(); src = document.selection.createRange();
          }else {
                 if (confirm ('mViệt hoán chuyển toàn bài?'))
                 currElm.document.body.innerHTML= document.VietInterface.getViet(currElm.document.body.innerHTML, 1, 0,BoDauMV+'|\\', 0); return;
                } 
       }
       if (src == null || src.text.length==0) { alert('Bài viết trống, không có gì để CHUYỂN.'); return;}
       else { 	 
               if (confirm ('Bắt Đầu hoán chuyển đoạn này???')) {
               	   src.text=document.VietInterface.getViet(src.text, 1, 0,BoDauMV+'|\\', 0);
                    
               }
            }
   } else {//moz
if(mvHTML){	  
//currElm.focus();
var sel=currElm.getSelection(),range = null;
mvbox=document;	
range = sel.getRangeAt(0)
var pos1 = range.startOffset
var node1 = range.endContainer;
var textMV=mvnode(range.cloneContents(), false) 
if (textMV=='') { alert('Please hi-light a section to convert');return}
var n=textMV.length
if (n>0) node1.deleteData(pos1, n);
	textMV=document.VietInterface.getViet(textMV, 1, 0,BoDauMV+'|\\', 0);
	node1.insertData(pos1,textMV)
}
	  	  var src = currElm;	  	 
          var contents=src.value; 
          if (contents.length==0) { alert('Bài viết trống, không có gì để CHUYỂN.'); return;}
          else { 
             src.value= document.VietInterface.getViet(contents, 1, 0,BoDauMV+'|\\', 0);	   
             
             }            	 
	      }//moz
   }//null   
}
}

var Kh1 ='<table border=0 bgcolor=#4274B6 cellspacing=0 cellpadding=1><tr><td width=100% ><table border=0 width=100% cellspacing=0 cellpadding=0 height=36><tr><td id=dragbar style=\'cursor:hand\' width=100% height=17><ilayer width=100% nSelectStart=\'return false\'><layer width=100% onMouseover=\'dragswitch=1;if (ns4) drag_dropns(showimageMV)\' onMouseout=\'dragswitch=0\' id=mvlayer ><a href=\'http://www.mviet.org\' target=0 style=text-decoration:none><font face=Verdana color=#FFFFFF><strong><small>&nbsp;mViệt</small></strong></font></a></layer></ilayer></td><td style=\'cursor:hand\'><a href=\'#\' onClick=\'hidebox();return false\'><img src=\''+folder+'close.gif\' width=14 height=14 border=0 style=\'position:relative;left:-1\'></a></td></tr><tr><td width=100% class=mvtabl style=\'padding:4px\' colspan=2>';
var Kh2 ='</td></tr></table>';
var Kh3='<table bgcolor=white cellspacing=0 border=0 align=\'center\'><tr><td width=370 height=116 nowrap align=center valign=middle>';
var iFr1 ='<iframe src=\''+folder; 
var mvKG = 'kieugo.htm\' width=380 height=115 align=center';
var mvCC = 'congcu.htm\' width=465 height=38 align=center';
var mvTK = 'tocky.htm\' width=400 height=150 align=center';
var mvHN = 'hoinga.htm\' width=460 height=125 align=center';
var mvHN0 = 'hoinga0.htm\' width=460 height=125 align=center';
var mvTD = 'tudien.htm\' width=140 height=90 align=center';
var mvHC = 'hoanchuyen.htm\' width=220 height=95 align=center';
var mvTT = 'timthe.htm\' width=220 height=95 align=center';
var mvCT = 'cautruc.htm\' width=422 height=218 align=center';
var iFr2 = ' frameborder=0 id=mvframe marginwidth=0 marginheight=0 scrolling=no ></iframe>';
var Kh5='<table bgcolor=white cellspacing=0 border=0 align=center><tr><td width=370 height=45 nowrap align=center valign=middle>';
var mvKC  = 'kieuchu.htm\' width=370 height=40 align=center'; 

function DisplayTCC(){
if(document.getElementById('showBD')){
   MVOnButton = On;MVOffButton =Off;
  if(document.all) showBD.innerHTML=DisplayBDCN();  
   else document.getElementById('showBD').innerHTML=DisplayBDCN()
}else if (document.getElementById('MVietOnOff')) {
   MVOnButton = On;MVOffButton=Off;OnOff = document.getElementById('MVietOnOff')
   if (MVOff)OnOff.innerHTML=MVOnButton;else OnOff.innerHTML=MVOffButton;
}
}

DisplayTCC();

//
// NhanTin
//

//onClick=xshowModalDialog(\
//"http://www.thanhda.com/mviet/dhtml/index2.htm\", 
//window, 
//\"dialogWidth:250px; dialogHeight:370px; resizable: no; help: no; status: no; scroll: no; \"); '
dFeatures = 'dialogHeight: 370px; dialogWidth: 250px; dialogTop: 200px; dialogLeft: 40px; edge: Raised; center: Yes; help: No; resizable: No; status: No;';
modalWin = '';

function xShowModalDialog( sURL, vArguments, sFeatures ){
if (vArguments==null||vArguments=='')vArguments='';
if (sFeatures==null||sFeatures=='')sFeatures=dFeatures;
if (window.navigator.appVersion.indexOf('MSIE')!=-1){
window.showModalDialog ( sURL, vArguments, sFeatures );
}else{
sFeatures = sFeatures.replace(/ /gi,'');
aFeatures = sFeatures.split(';');
sWinFeat = 'directories=0,menubar=0,titlebar=0,toolbar=0,';
for ( x in aFeatures )
{
aTmp = aFeatures[x].split(':');
sKey = aTmp[0].toLowerCase();
sVal = aTmp[1];
switch (sKey){
case 'dialogheight': sWinFeat += 'height='+sVal+','; pHeight = sVal; break;
case 'dialogwidth': sWinFeat += 'width='+sVal+','; pWidth = sVal; break;
case 'dialogtop': sWinFeat += 'screenY='+sVal+','; break;
case 'dialogleft': sWinFeat += 'screenX='+sVal+','; break;
case 'resizable': sWinFeat += 'resizable='+sVal+','; break;
case 'status':sWinFeat += 'status='+sVal+',';break;
case 'center':if ( sVal.toLowerCase() == 'yes' )
{sWinFeat += 'screenY='+((screen.availHeight-pHeight)/2)+',';sWinFeat += 'screenX='+((screen.availWidth-pWidth)/2)+',';}break;}
}
modalWin=window.open(String(sURL),'',sWinFeat);
if (vArguments!=null&&vArguments!=''){modalWin.dialogArguments=vArguments;}
}}
//
	function mvsave(str)
{ 
if (confirm ("Ghi chú: Chỉ điền tên bài khi save, Language cần là Unicode!")){
//str = "<html><head><title></title><meta http-equiv='Content-Type' content='text/html; charset=utf-8'></head><body>" +str;
//str += "</body></html>"
    mywin = window.open("text/html","mywin","width=1,height=1");
	mywin.document.open();
    //mywin.document.write("<plaintext>"); //remove for wysiwyg
	mywin.document.write(str);
	mywin.document.execCommand("saveAs",true);		
	mywin.document.close();
	mywin.close();
}
} 