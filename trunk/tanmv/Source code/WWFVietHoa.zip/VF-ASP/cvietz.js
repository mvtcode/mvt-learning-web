﻿function  pLZ(e){
var elm=e.currentTarget,ta=elm.value,B= elm.selectionStart,E= elm.selectionEnd,t= ta.substring(0,B), dd= ta.substr(E),lastInd =-1,n = t.length,spr=' \'?"(){}[]<>/-\n\r_'
if(t.charAt(n-1)==' '){if(key=='.'||key=='?'){elm.value = elm.value.substring(0,n-1)+elm.value.substring(end); elm.setSelectionRange(n-1,n-1);return} else return}
for(i=0; i<spr.length; i++) if (t.lastIndexOf(spr.charAt(i))>lastInd) lastInd = t.lastIndexOf(spr.charAt(i))
t=t.substring(lastInd+1);n=t.length;B=E-n
hnDisplayZ(t,key)
var kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
iD=-1;if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
var nMV='';if(t.length>0)if(iD>-1&&iD<12){nMV=VB(t,3,key,iD);if(eT==0){  sD(kL)  } }
else nMV=VB(t+key,4,'',-1)
var l=nMV.length,st=elm.value.substring(0,B)	
if(l<1)return
else{elm.value= st+nMV+elm.value.substring(E)
elm.setSelectionRange(st.length+l,st.length+l)
if (eT==0) e.preventDefault()
if (iHN[0]==1&& (iD==3||iD==4) )hnQuickZ(nMV, 0)
}}
function mvEvent(id){
var ua = navigator.userAgent.toLowerCase();isGecko = (ua.indexOf('gecko') != -1)
var frameHtml = "<html id='"+id+"' >\n";
frameHtml += "<head>\n";
frameHtml += "<style>\n";
frameHtml += "body {\n";
frameHtml += "	background: #FFFFFF;\n";
frameHtml += "	margin: 0px;\n";
frameHtml += "	padding: 0px;\n";
frameHtml += "}\n";
frameHtml += "</style>\n";
frameHtml += "</head>\n";frameHtml += "<body>\n";
frameHtml += "</body>\n";frameHtml += "</html>";

var oRTE = document.getElementById(id).contentWindow.document;
oRTE.open();oRTE.write(frameHtml);oRTE.close()
try {if (isGecko) {
oRTE.addEventListener('keypress', kb_handler, true); 
oRTE.addEventListener('keydown', kb_dn, true);
}
} catch (e) {if (isGecko) {setTimeout('mvEvent()', 10);} else {return false;}}
document.getElementById(id).contentDocument.designMode = 'on';
}
//
function kb_dn(evt) { if(evt.keyCode==Fonoff)MVietOnOffButton();}
function kb_handler(evt,rte) { var rte = evt.target.id; mvmoz(evt,rte);}
function mvmoz(evt,rte){
if (evt.keyCode==8|| evt.keyCode==13|| evt.keyCode==37 || evt.keyCode==38|| evt.keyCode==39|| evt.keyCode==40 || evt.keyCode==191) return;
else if (!MVOff){mvwindow =document.getElementById(rte).contentWindow;
mvbox = document;   
var sel=mvwindow.getSelection(),range = null;

mvwindow.focus()
range = sel ? sel.getRangeAt(0) : mvbox.createRange()
var pos1 = range.startOffset
var node1 = range.endContainer;
var textMV=mvnode(range.cloneContents(), false)
var n=textMV.length
if (n>0) node1.deleteData(pos1, n);
range.setEnd(node1, pos1);
range.setStart(node1, 0);
textMV=mvnode(range.cloneContents(), false)

n = textMV.length
var charCode = textMV.charCodeAt(n-1)
if (charCode ==32) { if(evt.charCode==46 ||evt.charCode==63 ) {range.setStart(node1, pos1-1);node1.deleteData(pos1-1, 1); return;}
else return}
key=String.fromCharCode(evt.charCode); 
var spr=" '?\"(){}[]<>/-."
if (charCode== 160 ||(n>0 && " ,.;-='\"?<>/\{}()*&1234567890".indexOf(textMV.charAt(n-1))>-1) 
||(n==0 && !evt.shiftKey)) {range.setStart(node1,pos1); return;}
var lastInd = -1 
for (i=0; i<spr.length; i++) if (textMV.lastIndexOf(spr.charAt(i))>lastInd) lastInd = textMV.lastIndexOf(spr.charAt(i))
tI=textMV.substring(lastInd+1);
hnDisplayZ(tI,key)
range.setStart(node1, pos1);  
var kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL);
iD=-1
if(nD>-1){var iT=0
for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}	
if(iD==8&&BoDauMV.indexOf(kL,nD+1)>-1)bt=1;else bt=0
}

if(tI.length>0){var nMV=''
if(iD>-1&&iD<12){nMV=VB(tI,3,key,iD)
if (iHN[0]==1&& (iD==3||iD==4) ) {hnQuickZ(nMV, 0); hnNew=0}
if(nMV!=tI && nMV.length>0){
node1.deleteData(lastInd+1, pos1-lastInd-1)
pos1 = range.startOffset
node1.insertData(lastInd+1,nMV)
newLen=nMV.length
range.setEnd(node1,lastInd+1+newLen)
range.setStart(node1,lastInd+1+newLen)
iD=-2 
}
if(eT==0){evt.preventDefault();  sD(kL) }
return; 
}else {tI=tI+key;nMV=VB(tI,4,'',-1)
if(nMV!=tI && nMV.length>0){node1.deleteData(lastInd+1, pos1-lastInd-1);pos1 = range.startOffset;node1.insertData(lastInd+1,nMV);
newLen=nMV.length;range.setEnd(node1,lastInd+1+newLen);range.setStart(node1,lastInd+1+newLen);iD=-2} 
eT=1; if(eT==0){evt.preventDefault();}
}}}}

function mvnode(root, toptag)
{var html = '';moz_check = /_moz/i;
switch (root.nodeType)
{case Node.ELEMENT_NODE: case Node.DOCUMENT_FRAGMENT_NODE:
{var closed;
if (toptag){
				closed = !root.hasChildNodes();
				html = '<' + root.tagName.toLowerCase();
				var attr = root.attributes;
				for (i = 0; i < attr.length; ++i)
				{
					var a = attr.item(i);
					if (!a.specified || a.name.match(moz_check) || a.value.match(moz_check))
					{continue;}
					html += " " + a.name.toLowerCase() + '="' + a.value + '"';
				}
				html += closed ? " />" : ">";
			}
			for (var i = root.firstChild; i; i = i.nextSibling)
			{html += mvnode(i, true);}
			if (toptag && !closed)
			{html += "</" + root.tagName.toLowerCase() + ">";}
		}
		break;

		case Node.TEXT_NODE:
		{html = root.data}
		break;
	}
	return html;
}

function hnQuickZ(word, ihn) {
var HNList ='';
if (MVhnVal > 0 && document.getElementById('mvframe') && document.getElementById('mvframe').contentDocument.BViet75) {
if (ihn==0) HNList = document.getElementById('mvframe').contentDocument.BViet75.duyetHN(word, 0 ); 
else if (ihn==1) HNList = document.getElementById('mvframe').contentDocument.BViet75.duyetSX(word, 0);
else if (ihn==2) { HNList = document.getElementById('mvframe').contentDocument.BViet75.duyetCT(word, 0);}
else if (ihn==3) { HNList = document.getElementById('mvframe').contentDocument.BViet75.duyetChTr(word, 0);}
else if (ihn==4) {  HNList = document.getElementById('mvframe').contentDocument.BViet75.duyetLN(word, 0);}
var hnIndex= HNList.indexOf('|',4);
if (hnIndex> -1  && HNList.substring(hnIndex+1) !='')
if (hnNew==0) {  hnNew=1; document.getElementById('mvframe').contentDocument.MVietForm.HNMsg.value = HNList.substring(hnIndex+1);}
else { document.getElementById('mvframe').contentDocument.MVietForm.HNMsg.value += '\n----------------\n'+ HNList.substring(hnIndex+1);}
}}
function hnDisplayZ(tI,Key){
var marker=' .?:,;-\n\r' 
if ( marker.indexOf(Key)>-1
	&& BoDauMV.indexOf(Key)==-1
	&& MVhnVal > 0 && document.getElementById('mvframe') && document.getElementById('mvframe').contentDocument.BViet75) {
var n = tI.length;
if (iHN[1]==1 && marker.indexOf(tI.charAt(n-1))==-1 && (tI.indexOf('s')==0 ||tI.indexOf('x')==0)) {hnQuickZ(tI, 1);}
if (iHN[4]==1 && marker.indexOf(tI.charAt(n-1))==-1 && (tI.indexOf('l')==0 ||tI.indexOf('n')==0)) {hnQuickZ(tI, 4);}
if (iHN[2]==1 && (tI.charAt(n-1)=='c' ||tI.charAt(n-1)=='t') ) hnQuickZ(tI, 2);
if (iHN[3]==1 && (tI.indexOf('ch')==0 ||tI.indexOf('tr')==0 ) ) hnQuickZ(tI, 3);
}
hnNew=0;}
