﻿function AddText(NewCode) 
	{
	if (document.myForm2.noidung.createTextRange && document.myForm2.noidung.caretPos) {
		var caretPos = document.myForm2.noidung.caretPos;
		caretPos.text = NewCode;
	} else {
		document.myForm2.noidung.value+=NewCode;
	}
	document.myForm2.noidung.focus();
	}

function bold() 
	{
	var text = getText();
	if (text)
		{
		AddTxt="[b]" + text + "[/b]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ in đậm:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[b]" + txt + "[/b]";
				AddText(AddTxt);
			}
		}
	}

function italicize() 
	{
	var text = getText();
	if (text)
		{
		AddTxt="[i]" + text + "[/i]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ in nghiêng:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[i]" + txt + "[/i]";
				AddText(AddTxt);
			}
		}
	}

function underline()
	{
	var text = getText();
  	if (text)
		{
		AddTxt="[u]" + text + "[/u]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ gạch chân:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[u]" + txt + "[/u]";
				AddText(AddTxt);
			}
		}
	}

function left()
	{
	var text = getText();
 	if (text)
		{
		AddTxt="[left]" + text + "[/left]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ canh trái:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[left]" + txt + "[/left]";
				AddText(AddTxt);
			}
		}
	}

function center()
	{
	var text = getText();
 	if (text)
		{
		AddTxt="[center]" + text + "[/center]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ canh giữa:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[center]" + txt + "[/center]";
				AddText(AddTxt);
			}
		}
	}

function right()
	{
	var text = getText();
 	if (text)
		{
		AddTxt="[right]" + text + "[/right]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung chữ canh phải:","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[right]" + txt + "[/right]";
				AddText(AddTxt);
			}
		}
	}

function hyperlink()
	{
	var text = getText();
	if (text)
		{
		txt=prompt("Nhập đường dẫn liên kết:","http://");
		txt2=txt
		if ((txt2==null) || (txt2=="") || (txt2=="http://"))
			{
				AddTxt=text;
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[url=\"" + txt2 + "\"]" + text + "[/url]";
				AddText(AddTxt);
			}
		} 
	else
		{ 
		txt3=prompt("Nhập nội dung hiển thị của liên kết:","");
		txt4=prompt("Nhập đường dẫn liên kết:","http://");
		if ((txt3!=null) && (txt3!="") && (txt4!=null) && (txt4!="")&& (txt4!="http://"))
			{
				AddTxt="[url=\"" + txt4 + "\"]" + txt3 + "[/url]";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="";
				AddText(AddTxt);
			}
		}
	}

function image()
	{
	var text = getText();
	if (text)
		{
		AddTxt="[img]" + text + "[/img]";
		AddText(AddTxt);
		}
	else
		{
		txt=prompt("Đường dẫn cho file hình ảnh:","http://");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[img]" + txt + "[/img]";
				AddText(AddTxt);
			}
		}
	}

function showfont(font)
	{
	var text = getText();
 	if (text)
 		{
		AddTxt="[font="+font+"]" + text + "[/font="+font+"]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung với font "+font+".","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[font="+font+"]"+txt+"[/font="+font+"]";
				AddText(AddTxt);
			}
		}
	document.myForm2.Font.selectedIndex = 0;
}


function showcolor(color)
	{
	var text = getText();
 	if (text)
 		{
		AddTxt="["+color+"]" + text + "[/"+color+"]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung với màu "+color+".","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="["+color+"]"+txt+"[/"+color+"]";
				AddText(AddTxt);
			}
		}
	document.myForm2.Color.selectedIndex = 0;
	}

function showsize(size)
	{
	var text = getText();
 	if (text)
 		{
		AddTxt="[size="+size+"]" + text + "[/size]";
		AddText(AddTxt);
		}
	else 
		{
		txt=prompt("Nhập nội dung với cỡ chữ "+size+".","");
		if ((txt==null) || (txt==""))
			{
				AddTxt="";
				AddText(AddTxt);
			}
		else
			{
				AddTxt="[size="+size+"]"+txt+"[/size]";
				AddText(AddTxt);
			}
		}
	document.myForm2.Color.selectedIndex = 0;
}

function storeCaret(ftext)
	{
	if (ftext.createTextRange)
		{
		ftext.caretPos = document.selection.createRange().duplicate();
		}
	}

function getText()
	{
	if (document.myForm2.noidung.createTextRange && document.myForm2.noidung.caretPos) 
		{
		return document.myForm2.noidung.caretPos.text;
		}
	else 
		{
		return '';
		}
	}