﻿function pL(mve){if (ready)pLB(mve);else if (mvHTML) pLX(mve);}
function pLB(mve){
S=document.selection.createRange()
if(!ready||S.text.length!=0||BoDauMV=='')return;
S3=S.duplicate(),iD=-1,kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
S3.moveStart('word',-1);t=S3.text
hnDisplay(t,key);
if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
if(t.charAt(t.length-1)==' '){if(key=='.'||key=='?'){S.moveStart('character',-1);S.text='';return}else return}
if(t.length>0){if(iD>-1&&iD<12){VanDisplay(3,key,iD);if(eT==0){mve.returnValue=false; sD(kL) } return}
else {VanDisplay(4,'',-1);if(eT==0)mve.returnValue=false}}}
function pLX(mve){
if(ready||mvHTML){
currElm=elm;
key=String.fromCharCode(mve.keyCode);
S=document.selection.createRange();
if(S.text.length==0&&BoDauMV!=''&&!MVOff)pLX1(elm,mve)}}	
function pLX1(txtArea,mvevent){
	S=document.selection.createRange()
S3=S.duplicate(),iD=-1,kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
S3.moveStart('word',-1);t=S3.text
if(nD>-1){var iT=0;for(i=0;i<12;i++){if(BoDauMV.indexOf(kL,iT)>-1){iT=BoDauMV.indexOf('|',iT+1)
}else{iD=i;break}}
if(iD==8&&BoDauMV.indexOf(kL,nD+1)>-1)bt=1;else bt=0}
if(t.charAt(t.length-1)==' ')
{if(key=='.'||key=='?'){S.moveStart('character',-1);S.text='';return}else return}
if(t.length>0){
     if(iD>-1&&iD<12){
      VanDisplay(3,key,iD);
if(eT==0) {mvevent.returnValue=false;
 sD(kL) 
}
return}
else {VanDisplay(4,'',-1);if(eT==0)mvevent.returnValue=false}}}
//f:VanDisplay
function VanDisplay(n,value,ord){S=document.selection.createRange()
S3=S.duplicate();S3.moveStart('character',-1);
if(S3.text.length==0||' ,.;-=\'"?<>/\{}()*&1234567890'.indexOf(S3.text)>-1)eT=1
else{
S2=S.duplicate();
S2.moveStart('word',-1);tI=S2.text; if(n==4)tI+=key  
var tO=VB(tI,n,value,ord);if(tO!=''&& tO!=null){S2.text=tO
if(n==3 && iHN[0]==1&& (ord==3||ord==4)) {hnQuick(tO, 0);hnNew=0}

}
}}
function mvEvent(id){
var oB= frames[id];
 oB.document.designMode='On'
 oB.document.attachEvent('onkeypress', function(){ pLF(oB) ;})
 oB.document.attachEvent('onclick',function(){ mvHTML = true;})	
 oB.document.attachEvent('onkeydown',function(){ mvHTML = true; if(oB.event.keyCode==Fonoff) MVietOnOffButton();
else if(oB.event.keyCode==Ftcc && !document.getElementById('showBD') && document.getElementById('showpopup')){
if (document.getElementById('mvframe')){if(f)showpopup.innerHTML='';else document.getElementById('showpopup').innerHTML=''; }
else {showbox();if(f)showpopup.innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2;else document.getElementById('showpopup').innerHTML=Kh1+iFr1+mvCC+iFr2+Kh2;}
}})}

function pLF(oB){
var evf=oB.event
currElm=evf.srcElement;//chinh
var kv=evf.keyCode;
var key=String.fromCharCode(kv)
if (MVOff) return;
var S=oB.document.selection.createRange();

if(S.text.length!=0||BoDauMV=='')return;

var S3=S.duplicate(),iD=-1,kL=key.toLowerCase(),nD=BoDauMV.indexOf(kL)
S3.moveStart('word',-1);t=S3.text;
hnDisplay(t,key);
if (kv==32|| kv==191) return;
if(nD>-1){var iT=0;for(i=0;i<12;i++)if(BoDauMV.indexOf(kL,iT)>-1)iT=BoDauMV.indexOf('|',iT+1);else{iD=i;break}}
if(t.charAt(t.length-1)==' '){if(key=='.'||key=='?'){S.moveStart('character',-1);S.text='';return}else return}
if(t.length>0){if(iD>-1&&iD<12){VanDisplayF(oB,3,key,iD,'');
if(eT==0){evf.returnValue=false; sD(kL)  }
return}
else {VanDisplayF(oB,4,'',-1,key);
if(eT==0)evf.returnValue=false
}}
}
//f:VanDisplay
function VanDisplayF(oB,n,value,ord,key){
S=oB.document.selection.createRange()
S3=S.duplicate();S3.moveStart('character',-1);
if(S3.text.length==0||" ,.;-='\"?<>/\{}()*&1234567890".indexOf(S3.text)>-1)eT=1
else{
S2=S.duplicate();
S2.moveStart('word',-1);tI=S2.text; if(n==4)tI+=key
var tO=VB(tI,n,value,ord);if(tO!=''&& tO!=null){S2.text=tO
if(n==3 && iHN[0]==1&& (ord==3||ord==4)) {hnQuick(tO, 0);hnNew=0}
}
}}

function hnQuick(word, ihn) {
if (MVhnVal > 0 && window.mvframe && window.mvframe.document.BViet75) {
var HNList ='';
if (ihn==0) HNList = window.mvframe.document.BViet75.duyetHN(word, 0 );
else if (ihn==1) HNList = window.mvframe.document.BViet75.duyetSX(word, 0);
else if (ihn==2) {  HNList = window.mvframe.document.BViet75.duyetCT(word, 0);}
else if (ihn==3) {  HNList = window.mvframe.document.BViet75.duyetChTr(word, 0);}
else if (ihn==4) {  HNList = window.mvframe.document.BViet75.duyetLN(word, 0);}
var hnIndex= HNList.indexOf('|',4);
if (hnIndex> -1  && HNList.substring(hnIndex+1) !='')
if (hnNew==0) {  hnNew=1; window.mvframe.MVietForm.HNMsg.value = HNList.substring(hnIndex+1);}
else { window.mvframe.MVietForm.HNMsg.value += '\n----------\n'+ HNList.substring(hnIndex+1);}
}}
function hnDisplay(tI,Key){
var marker=' .?:,;-\n\r'
if ( marker.indexOf(Key)>-1
	&& BoDauMV.indexOf(Key)==-1
	&& MVhnVal > 0
	&& window.mvframe && window.mvframe.document.BViet75){
var n = tI.length;
if (iHN[1]==1 && marker.indexOf(tI.charAt(n-1))==-1 && (tI.indexOf('s')==0 ||tI.indexOf('x')==0)) {hnQuick(tI, 1);}
if (iHN[4]==1 && marker.indexOf(tI.charAt(n-1))==-1 && (tI.indexOf('l')==0 ||tI.indexOf('n')==0)) {hnQuick(tI, 4);}
if (iHN[2]==1 && (tI.charAt(n-1)=='c' ||tI.charAt(n-1)=='t') ) hnQuick(tI, 2);
if (iHN[3]==1 && (tI.indexOf('ch')==0 ||tI.indexOf('tr')==0 ) ) hnQuick(tI, 3);
}
hnNew=0;}