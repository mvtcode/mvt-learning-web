﻿function getcookie(name){var dc = document.cookie,pfix = name + '=';bn = dc.indexOf('; ' + pfix);if (bn == -1) {bn = dc.indexOf(pfix);if (bn != 0) return null} else bn += 2;var ed = dc.indexOf(';', bn);if (ed == -1)ed = dc.length;return unescape(dc.substring(bn + pfix.length, ed));}
function getMV(mvName, mvDef){var t = getcookie(mvName),tp=mvDef; if(t) tp=t; return tp;}
function setMV(mvVal, mvName){document.cookie = mvName+'='+mvVal+'; expires=Monday, 04-Apr-2010 05:00:00 GMT';}
var tempBoDauMV=getMV('BoDau', '')
if (tempBoDauMV!=''){ds=true;BoDauMV=tempBoDauMV;}
var jvmload=false
var pHa='<img src=\''
var pHb=' onClick=\''
var pT='MVietOnOffButton();\' alt=\'F'
var pT1=':  Tắt/Bật mViệt\'>';
var On = pHa+folder+'on.gif\''+pHb+ pT+(Fonoff-111)+pT1
var Off =pHa+folder+'off.gif\''+pHb+ pT+(Fonoff-111)+pT1
var On1 = pHa+'on.gif\''+pHb+'parent.'+pT+(parent.Fonoff-111)+pT1
var Off1 =pHa+'off.gif\''+pHb+'parent.'+pT+(parent.Fonoff-111)+pT1

var MVOnButton,MVOffButton,OnOff
function MVietOnOffButton (){
if (document.getElementById('MVietOnOff')) {MVOnButton = On;MVOffButton=Off;OnOff = document.getElementById('MVietOnOff')}
else if (document.getElementById('mvframe')){
  MVOnButton = On1; MVOffButton =Off1;
  if(document.all)OnOff = window.mvframe.document.getElementById('MVietOnOff');
  else OnOff=document.getElementById('mvframe').contentDocument.getElementById('MVietOnOff')
} 
if (MVOff) {MVOff=false; if (OnOff!=null) OnOff.innerHTML=MVOffButton;} 
else {MVOff=true; if (OnOff!=null) OnOff.innerHTML=MVOnButton;} 
}

function DisplayBDCN (){	
var bD = BoDauMV.split('|');
var bDTit= '&nbsp;Sắc&nbsp;|&nbsp;Huyền&nbsp;|&nbsp;Hỏi&nbsp;|&nbsp;Ngã&nbsp;|&nbsp;Nặng&nbsp;|&nbsp;Nón&nbsp;|&nbsp;Móc&nbsp;|&nbsp;Trăng&nbsp;|Gạch'.split('|');
var strBDCN='<table class=KhungDau><tr>';
if(document.getElementById('showBD') || (!document.getElementById('MVietOnOff') && !document.getElementById('showBD'))){
	strBDCN +='<td align=center valign=middle><div id=MVietOnOff >'
	if (MVOff)strBDCN +=MVOnButton; else strBDCN += MVOffButton	
    strBDCN  +='</div></td>';
}

var headMV = '<td align=center class=KhungTitleDau >' + '<SPAN CLASS=TitleDau > ';
var headRedMV = '<td align=center class=KhungTitleDau >' + '<SPAN CLASS=TitleDau > ';
var tailMV = '</SPAN><br><SPAN CLASS=Dau >';
var endMV = '</SPAN></td>';
for (var i =0; i< 9; i++){ 
  if (bD[i].length==0) bD[i]='&nbsp;';
  strBDCN  += headMV+ bDTit[i]+ tailMV+ bD[i]+ endMV; 
}
strBDCN  += headRedMV+'Thay'+ tailMV;
strBDCN  += '<img src=\''+folder+ 'n_pencil.gif\' '
strBDCN  += ' onClick="window.focus(); if(document.all) showBD.innerHTML=Kh3+iFr1+mvKG+iFr2+Kh2; else document.getElementById(\'showBD\').innerHTML=Kh3+iFr1+mvKG+iFr2+Kh2;" '
strBDCN  += ' alt=\'Kiểu Gõ\'  width=12 height=15>' + endMV; 
//chinh
strBDCN  += headRedMV+ 'Chỉnh'+ tailMV
strBDCN  += '<img src=\''+folder+'n_wand.gif\' onClick="window.focus();checkBDCD(); " alt=\'Dấu Rời\'  width=12 height=15>' + endMV;
//chinh
strBDCN  += headRedMV+'Dùng'+ tailMV
strBDCN  += '<img src=\''+folder+'help2.gif\' onClick="window.open(\''+folder+'huongdan11A.htm\',\'hd\', \'toolbar=no,location=no, scrollbars=yes, resizable=yes, width=470,height=460\'); " alt=\'Hướng Dẫn\'  width=15 height=15>' + endMV; 

strBDCN  += '</tr></table>';
return strBDCN;	
}

//checkBDCN
function checkBDCD(){
if(!navigator.javaEnabled()) alert('Please download JVM at java.sun.com to use this feature');
else {	
	
	var appmviet='<applet code=VietInterfaceIE5.class  height=1 width=1 NAME=VietInterface ARCHIVE=VT70.jar CODEBASE=./mvF2/  ALT=\'Your browser understands the applet tag but is not displaying any applet.\' ></applet>'
	if(!jvmload){if (document.all)jvmdiv.innerHTML = appmviet;else document.getElementById('jvmdiv').innerHTML= appmviet;jvmload=true}
  if (currElm==null) alert('Please hi-light a section to convert');
  else { 
    if (document.all) {
       var src = currElm.document.selection.createRange(); 
       if (src.text.length == 0 ){ 
          if(!mvHTML){ currElm.select(); src = document.selection.createRange();}
          else {if (confirm ('mViệt hoán chuyển toàn bài?'))currElm.document.body.innerHTML= document.VietInterface.getViet(currElm.document.body.innerHTML, 1, 0,BoDauMV+'|\\', 0); return;} 
       }
       if (src == null || src.text.length==0) { alert('Bài viết trống, không có gì để CHUYỂN.'); return;}
       else { 	   
        if (confirm ('Bắt Đầu hoán chuyển đoạn này?')) src.text = document.VietInterface.getViet(src.text, 1, 0,BoDauMV+'|\\', 0);}
	  } else {//moz
if(mvHTML){	  
currElm.focus();
var sel=currElm.getSelection(),range = null;
mvbox=document;	
range = sel.getRangeAt(0)
var pos1 = range.startOffset
var node1 = range.endContainer;
var textMV=mvnode(range.cloneContents(), false) 
if (textMV=='') { alert('Please hi-light a section to convert');return}
var n=textMV.length
if (n>0) node1.deleteData(pos1, n);
	textMV=document.VietInterface.getViet(textMV, 1, 0,BoDauMV+'|\\', 0);
	node1.insertData(pos1,textMV)
return;
}
	  	  var src = currElm;	  	 
          var contents=src.value; 
          if (contents.length==0) { alert('Bài viết trống, không có gì để CHUYỂN.'); return;}
          else { 	   
             src.value=document.VietInterface.getViet(contents, 1, 0,BoDauMV+'|\\', 0);
             }            	 
	      }//moz
   }//null   
}
}


//checkBDCN
var Kh1 ='<table border=0 bgcolor=#4274B6 cellspacing=0 cellpadding=1><tr><td width=100% ><table border=0 width=100% cellspacing=0 cellpadding=0 height=36><tr><td id=dragbar style=\'cursor:hand\' width=100% height=17><ilayer width=100% nSelectStart=\'return false\'><layer width=100% onMouseover=\'dragswitch=1;if (ns4) drag_dropns(showimageMV)\' onMouseout=\'dragswitch=0\' id=mvlayer ><a href=\'http://www.mviet.org\' target=0 style=text-decoration:none><font face=Verdana color=#FFFFFF><strong><small>&nbsp;mViệt</small></strong></font></a></layer></ilayer></td><td style=\'cursor:hand\'><a href=\'#\' onClick=\'hidebox();return false\'><img src=\''+folder+'close.gif\' width=14 height=14 border=0 style=\'position:relative;left:-1\'></a></td></tr><tr><td width=100% class=mvtabl style=\'padding:4px\' colspan=2>';
var Kh2 ='</td></tr></table>';
var Kh3='<table bgcolor=white cellspacing=0 border=0 align=\'center\'><tr><td width=370 height=116 nowrap align=center valign=middle>';
var iFr1 ='<iframe src=\''+folder; 
var mvKG = 'kieugo.htm\' width=380 height=115 align=center';
var mvCC = 'congcu.htm\' width=465 height=35 align=center';
var mvTK = 'tocky.htm\' width=400 height=150 align=center';
var mvHN = 'hoinga.htm\' width=460 height=125 align=center';
var mvHN0 = 'hoinga0.htm\' width=460 height=125 align=center';
var mvTD = 'tudien.htm\' width=140 height=90 align=center';
var mvHC = 'hoanchuyen.htm\' width=220 height=95 align=center';
var mvTT = 'timthe.htm\' width=220 height=95 align=center';
var mvCT = 'cautruc.htm\' width=422 height=218 align=center';
var iFr2 = ' frameborder=0 id=mvframe marginwidth=0 marginheight=0 scrolling=no ></iframe>';
var Kh5='<table bgcolor=white cellspacing=0 border=0 align=center><tr><td width=370 height=45 nowrap align=center valign=middle>';
var mvKC  = 'kieuchu.htm\' width=370 height=40 align=center'; 

function DisplayTCC(){
if(document.getElementById('showBD')){
   MVOnButton = On;MVOffButton =Off;
  if(document.all) showBD.innerHTML=DisplayBDCN();  
   else document.getElementById('showBD').innerHTML=DisplayBDCN()
}else if (document.getElementById('MVietOnOff')) {
   MVOnButton = On;MVOffButton=Off;OnOff = document.getElementById('MVietOnOff')
   if (MVOff)OnOff.innerHTML=MVOnButton;else OnOff.innerHTML=MVOffButton;
}
}

DisplayTCC();

