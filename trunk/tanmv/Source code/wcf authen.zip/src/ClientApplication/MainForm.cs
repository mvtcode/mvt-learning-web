﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Net;

namespace WindowsClient
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void AuthenticateButton_Click(object sender, EventArgs e)
        {
            AuthSvc.AuthenticationServiceClient client = new AuthSvc.AuthenticationServiceClient();

            using (new OperationContextScope(client.InnerChannel))
            {
                bool result = client.Login("tom", "chicago12", string.Empty, true);
                var responseMessageProperty = (HttpResponseMessageProperty)OperationContext.Current.IncomingMessageProperties[HttpResponseMessageProperty.Name];

                if (result)
                {
                    Globals.Cookie = responseMessageProperty.Headers.Get("Set-Cookie");
                    MessageBox.Show(result.ToString() + Environment.NewLine + Globals.Cookie);
                }
            }
        }

        private void InvokeUtility_Click(object sender, EventArgs e)
        {
            // Cookie attaching happens in the background
            UtilSvc.UtilityServiceClient utilClient = new UtilSvc.UtilityServiceClient();
            try
            {
                string result = utilClient.GetData(10);
                MessageBox.Show(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }
    }
}
