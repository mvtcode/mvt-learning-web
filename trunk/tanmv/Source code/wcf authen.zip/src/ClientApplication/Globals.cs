﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsClient
{
    public class Globals
    {
        public static string Cookie
        {
            get;
            set;
        }
    }
}
