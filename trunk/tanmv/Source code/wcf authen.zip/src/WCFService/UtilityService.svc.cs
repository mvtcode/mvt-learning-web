﻿using System.ServiceModel;
using System.Security.Permissions;
using System.ServiceModel.Activation;
using System.Security.Principal;
using System.ServiceModel.Channels;

namespace WCFService
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class UtilityService : IUtilityService
    {
        [PrincipalPermission(SecurityAction.Demand, Role = "Read")]
        public string GetData(int i)
        {
            string result = "You Entered: " + i.ToString();

            return result;
        }
    }
}
