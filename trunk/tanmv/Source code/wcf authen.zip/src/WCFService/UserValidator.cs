﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WCFService
{
    /// <summary>
    /// User Name Password Validator
    /// </summary>
    public class UserValidator
    {
        public bool IsUserValid(string userName, string password, out string commaSeparatedRoles)
        {
            commaSeparatedRoles = string.Empty;

            bool result = (userName == "tom") && (password == "chicago12");

            if (result) // If valid user return the Roles of user
                commaSeparatedRoles = "Read,Write";
            
            return result;
        }
    }
}