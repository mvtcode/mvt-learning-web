﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using ASPNETChatControl;
using ASPNETChatControl.DAL.SqlServer;
using SampleCSharpApp.SampleContactListProvider;

namespace SampleCSharpApp
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            //Uncomment the following line to use the custom contact list provider
            //ChatControl.ContactListProvider = new SampleContactListProvider();

            //Uncomment the following line to use Sql Server Data Provider
            //ChatControl.DataProvider = new SqlDataProvider();

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}