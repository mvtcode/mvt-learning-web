﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ASPNETChatControl.Extensibility;
using ASPNETChat.DataObjects;

namespace SampleCSharpApp.SampleContactListProvider
{
    public class SampleContactListProvider : ContactListProvider
    {
        public override List<ASPNETChat.DataObjects.ContactStatus> GetContactsWithGroups(string userId)
        {
            var contacts = base.GetContactsWithGroups(userId);

            //Uncomment the following loop to add dummy users to the contact list

            //for (int i = 0; i < 5; i++)
            //{
            //    var dummyContact = new ContactStatus();
            //    dummyContact.UserId = "DummyUser" + i.ToString();
            //    dummyContact.Username = "DummyUser" + i.ToString();
            //    contacts.Add(dummyContact);
            //}

            foreach (ContactStatus cs in contacts)
            {
                cs.GroupName = cs.Username.Substring(0, 1).ToUpper();
            }

            return contacts;
        }
    }
}
