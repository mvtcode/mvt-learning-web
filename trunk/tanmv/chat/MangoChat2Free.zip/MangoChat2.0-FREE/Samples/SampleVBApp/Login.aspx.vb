﻿Imports ASPNETChatControl

Partial Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnSubmit.Click
        If Not ChatControl.CurrentChatSession Is Nothing Then
            ChatControl.StopSession()
        End If

        ChatControl.StartSession(txtLoginName.Text, txtLoginName.Text, txtAvatarPath.Text.Trim())
        Response.Redirect("~/Sample.aspx")
    End Sub
End Class