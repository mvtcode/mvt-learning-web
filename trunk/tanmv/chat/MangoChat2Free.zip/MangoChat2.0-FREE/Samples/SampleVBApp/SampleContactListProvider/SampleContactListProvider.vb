﻿Imports ASPNETChatControl.Extensibility
Imports ASPNETChat.DataObjects

Public Class SampleContactListProvider
    Inherits ContactListProvider

    

    Public Overrides Function GetContactsWithGroups(ByVal userId As String) As System.Collections.Generic.List(Of ASPNETChat.DataObjects.ContactStatus)

        Dim contacts As List(Of ContactStatus) = MyBase.GetContactsWithGroups(userId)

        'Uncomment the following loop to add dummy users to the contact list

        'For i As Integer = 1 To 10
        '    Dim dummyContact As ContactStatus = New ContactStatus
        '    dummyContact.UserId = "DummyUser" & i.ToString()
        '    dummyContact.Username = "DummyUser" & i.ToString()
        '    contacts.Add(dummyContact)
        'Next

        For Each cs As ContactStatus In contacts
            cs.GroupName = cs.Username.Substring(0, 1).ToUpper()
        Next

        Return contacts
    End Function

End Class
