CREATE TABLE Session
(
	Id varchar(255)  PRIMARY KEY,
	UserId varchar(255) NOT NULL,
	Username nvarchar(255) NOT NULL,
	ChatPhotoName nvarchar(255),
	LastActivityTime datetime NOT NULL
)

CREATE TABLE [Message]
(
	Id bigint identity(1,1) PRIMARY KEY,
	MessageListSessionId varchar(255) NOT NULL,
	SenderUserId varchar(255) NOT NULL,
	SenderUsername nvarchar(255) NOT NULL,
	RecipientUserId varchar(255) NOT NULL,
	RecipientUsername nvarchar(255) NOT NULL,
	MessageContents nvarchar(1000) NOT NULL,
	IsTyping bit NOT NULL,
	MessageTime datetime NOT NULL
)

CREATE TABLE [LastContactStatus]
(
	Id bigint identity(1,1) PRIMARY KEY,
	SessionId varchar(255) NOT NULL,
	UserId varchar(255),
	Username nvarchar(255),
	StatusId int NOT NULL
)