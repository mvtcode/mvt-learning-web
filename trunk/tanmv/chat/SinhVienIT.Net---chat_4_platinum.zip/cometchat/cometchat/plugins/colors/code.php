<?php
$plugininfo = array('colors','Color your text');