<?php
$plugininfo = array('screenshare','Screensharing');