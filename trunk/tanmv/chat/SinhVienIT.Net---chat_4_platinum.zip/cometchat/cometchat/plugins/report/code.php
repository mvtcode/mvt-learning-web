<?php
$plugininfo = array('report','Report Conversation');