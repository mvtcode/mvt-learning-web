<?php
$plugininfo = array('block','Block User');