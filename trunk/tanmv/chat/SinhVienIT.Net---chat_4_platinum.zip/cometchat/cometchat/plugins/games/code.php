<?php
$plugininfo = array('games','Two Player Games');