<?php
		if (file_exists(dirname(__FILE__).DIRECTORY_SEPARATOR."lang/".$lang.".php")) {
			include dirname(__FILE__).DIRECTORY_SEPARATOR."lang/".$lang.".php";
		} else {
			include dirname(__FILE__).DIRECTORY_SEPARATOR."lang/en.php";
		}

		foreach ($filetransfer_language as $i => $l) {
			$filetransfer_language[$i] = str_replace("'", "\'", $l);
		}
?>

(function($){   
  
	$.ccfiletransfer = (function () {

		var title = '<?php echo $filetransfer_language[0];?>';

        return {

			getTitle: function() {
				return title;	
			},

			init: function (id) {
				baseUrl = $.cometchat.getBaseUrl();
				baseData = $.cometchat.getBaseData();

				window.open (baseUrl+'plugins/filetransfer/index.php?id='+id+'&basedata='+baseData, 'filetransfer',"status=0,toolbar=0,menubar=0,directories=0,resizable=0,location=0,status=0,scrollbars=0, width=400,height=170"); 
			}

        };
    })();
 
})(jqcc);