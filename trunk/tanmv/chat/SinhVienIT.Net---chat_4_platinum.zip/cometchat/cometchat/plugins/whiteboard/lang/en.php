<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$whiteboard_language[0] = 'Share a whiteboard';
$whiteboard_language[1] = 'Please wait atleast 10 seconds before trying to share again.';
$whiteboard_language[2] = 'has shared his/her whiteboard with you.';
$whiteboard_language[3] = 'Click here to view';
$whiteboard_language[4] = 'or simply ignore this message.';
$whiteboard_language[5] = 'has successfully shared his/her whiteboard.';
$whiteboard_language[6] = 'is now viewing your whiteboard.';
$whiteboard_language[7] = 'has shared a whiteboard.';
$whiteboard_language[8] = 'Click here to view';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////