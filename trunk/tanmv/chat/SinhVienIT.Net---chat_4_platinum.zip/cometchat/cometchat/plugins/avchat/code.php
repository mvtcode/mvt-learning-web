<?php
$plugininfo = array('avchat','Audio/Video Chat');