<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$avchat_language[0] = "Inizia una Video/Audio Chat";
$avchat_language[1] = "Asetta almeno 10 secondi prima di inviare un altra richiesta";
$avchat_language[2] = "ha inviato una richiesta per audio/video chat .";
$avchat_language[3] = "Clicca qui per accettare";
$avchat_language[4] = "o semplicemente ignora questo messaggio.";
$avchat_language[5] = "ha inviato una richiesta d Audio/Video Chat.";
$avchat_language[6] = "ha accettato la tua richiesta di Audio/Video Chat.";
$avchat_language[7] = "Clicca qui per aprire la finestra di Video Chat";
$avchat_language[8] = "Audio/Video Chat";
$avchat_language[9] = "Problemi di Connessione?";
$avchat_language[10] = <<<EOD
There are several reasons why the audio/video chat may be stuck at initializing:
<br/><br/>
1. Audio/video chat requires P2P to establish connection. In order for it to work, your firewall must be configured to allow outgoing UDP traffic. While this is the case with most consumer or small office/home office (SOHO) firewalls, many corporate firewalls block UDP traffic altogether.
<br/><br/>
2. The user at the other end is behind a UDP blocking firewall and is unable to connect to you.
<br/><br/>
3. Our servers are facing issues and you are unable to connect.

EOD;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>