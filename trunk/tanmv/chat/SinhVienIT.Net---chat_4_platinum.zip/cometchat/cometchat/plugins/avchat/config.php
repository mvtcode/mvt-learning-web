<?php

$connectUrl = 'rtmfp://stratus.rtmfp.net';
$developerKey = 'b72b713a18065673cdc1064e-0a89db06e6f8';