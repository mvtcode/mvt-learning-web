<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$language[0] = 'Opzioni Chat';
$language[1] = 'Scrivi il tuo Status e Premi Enter!';
$language[2] = 'Mio Status';
$language[3] = 'Disponibile';
$language[4] = 'Occupato';
$language[5] = 'Invisibile';
$language[6] = '';
$language[7] = '';
$language[8] = 'Effettua il login per usarela chat';
$language[9] = 'Chi e\' online';
$language[10] = 'Io';
$language[11] = 'Offline';
$language[12] = 'Chi e\'s Online';
$language[13] = 'Disabilita notifica sonora';
$language[14] = 'Non hai ancora nessun amico. Aggiungi amici per usarela chat';
$language[15] = 'Nuovo messaggio...';
$language[16] = '';
$language[17] = 'Offline';
$language[18] = 'Trova un utente';
$language[19] = '<br/><span style=\'color:#999\'>e\' online</span>';
$language[20] = '<br/><span style=\'color:#999\'>e\' offline</span>';
$language[21] = '<br/><span style=\'color:#999\'>e\' online (occupato)</span>';
$language[22] = 'Imposta il miostatus';
$language[23] = 'Sono...';
$language[24] = 'Disabilita notifiche popup';
$language[25] = '';
$language[26] = 'Inizia a chattare!';
$language[27] = 'Chiudi la barra';
$language[28] = 'Nessuno dei tuoi amici e\' online al momento. Prova dopo.';
$language[29] = 'Nessuno dei tuoi amici e\' online al momento. Prova dopo.';
$language[30] = 'Sono disponibile';
$language[31] = 'Sono occupato';
$language[32] = 'Sono offline';
$language[33] = 'Sono offline';
$language[34] = 'Sono assente';
$language[35] = ' | ';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////