<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
<style>
html, body {
	overflow:hidden;
	width: 500px;
}
</style>
</head>

<body>

<div id="wrapper">
    <div class="addthis_toolbox addthis_32x32_style addthis_default_style">
	<a class="addthis_button_facebook"></a>    
	<a class="addthis_button_twitter"></a>
	<a class="addthis_button_myspace"></a>
	<a class="addthis_button_stumbleupon"></a>
	<a class="addthis_button_reddit"></a>
	<a class="addthis_button_delicious"></a>
	<a class="addthis_button_digg" title="Digg This"></a>
	<a class="addthis_button_google"></a>
	<a class="addthis_button_favorites" title="Bookmark this Page"></a>
    </div>
</div>
<script>
var parenttitle = parent.document.title;
var parenturl = parent.document.location.href;
var addthis_share =
{
url:parenturl,
title:parenttitle,
templates: {
	twitter: '{{title}}: {{url}}'
}
}
</script>
<script src="sharethis.js"></script>
</body>
</html>
