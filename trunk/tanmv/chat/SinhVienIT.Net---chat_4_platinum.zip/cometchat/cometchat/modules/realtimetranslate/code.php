<?php
$trayiconinfo = array('realtimetranslate','Translate Conversations');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgncmVhbHRpbWV0cmFuc2xhdGUnLCdUcmFuc2xhdGUgQ29udmVyc2F0aW9ucycsJ21vZHVsZXMvcmVhbHRpbWV0cmFuc2xhdGUvaW5kZXgucGhwJywnX3BvcHVwJywnMjgwJywnMzAwJywnJywnMScpOw==';