<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$chatrooms_language[0] = 'Esegui il login per usare le chatrooms.';
$chatrooms_language[1] = 'Scegli pubbliche/private chat che vuoi entrare';
$chatrooms_language[2] = 'Crea Chatroom';
$chatrooms_language[3] = 'Generale';
$chatrooms_language[4] = '<a href="javascript:void(0);" onclick="javascript:leaveChatroom()">Lascia la stanza</a> | <a href="javascript:void(0);" onclick="javascript:inviteUser()">Invita un utente</a>';
$chatrooms_language[5] = 'Gli inviti alla room non verrano mostrati nella stanza';
$chatrooms_language[6] = 'Io';
$chatrooms_language[7] = ':  ';
$chatrooms_language[8] = 'Inserisci la password per la chat';
$chatrooms_language[9] = 'Popout';
$chatrooms_language[10] = 'Chiudi popout';
$chatrooms_language[11] = 'Una sessione di popout o un altra finestra chat è gia attiva.Chiudi le altre finestre per continuare.';
$chatrooms_language[12] = 'Click qua per tornare indietro';
$chatrooms_language[13] = ' ha lascialto la chatroom';
$chatrooms_language[14] = ' e\' entrato nella chatroom';
$chatrooms_language[15] = 'Chiusura finestra';
$chatrooms_language[16] = 'Utenti invitati correttamente';
$chatrooms_language[17] = 'Utenti invitati correttamente';
$chatrooms_language[18] = 'ti ha invitato ad entrare in chatroom. ';
$chatrooms_language[19] = 'Click qui per entrare';
$chatrooms_language[20] = 'Invita Utenti';
$chatrooms_language[21] = 'Seleziona Utenti';
$chatrooms_language[22] = 'Invita Utente';
$chatrooms_language[23] = 'Password non corretta. Riprova.';
$chatrooms_language[24] = '<img src="lock.png">';
$chatrooms_language[25] = '<img src="user.png">';
$chatrooms_language[26] = 'Inserisci la password';
$chatrooms_language[27] = 'Nome';
$chatrooms_language[28] = 'Tipo';
$chatrooms_language[29] = 'Stanza Pubblica';
$chatrooms_language[30] = 'Stanza protetta da password';
$chatrooms_language[31] = 'Stanza solo a invito';
$chatrooms_language[32] = 'Password';
$chatrooms_language[33] = 'Crea stanza';
$chatrooms_language[34] = 'online';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////