<?php
$trayiconinfo = array('chatrooms','Chatrooms');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnY2hhdHJvb21zJywnQ2hhdHJvb21zJywnbW9kdWxlcy9jaGF0cm9vbXMvaW5kZXgucGhwJywnX3BvcHVwJywnNTAwJywnMzAwJywnJywnMScpOw';