<?php
$trayiconinfo = array('translate','Page Translate (alternative version)');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgndHJhbnNsYXRlMicsJ1RyYW5zbGF0ZSBUaGlzIFBhZ2UnLCdtb2R1bGVzL3RyYW5zbGF0ZTIvaW5kZXgucGhwJywnX3BvcHVwJywnMjgwJywnMzAwJywnJywnMScpOw';