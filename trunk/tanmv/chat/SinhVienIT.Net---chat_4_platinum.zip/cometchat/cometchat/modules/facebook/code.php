<?php
$trayiconinfo = array('facebook','Facebook Fan Page');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgnZmFjZWJvb2snLCdGYWNlYm9vayBGYW4gUGFnZScsJ21vZHVsZXMvZmFjZWJvb2svaW5kZXgucGhwJywnX3BvcHVwJywnNTAwJywnMzAwJywnJywnMScpOw';