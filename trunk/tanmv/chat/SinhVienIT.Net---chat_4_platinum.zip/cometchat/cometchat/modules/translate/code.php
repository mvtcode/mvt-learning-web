<?php
$trayiconinfo = array('translate','Page Translate');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgndHJhbnNsYXRlJywnVHJhbnNsYXRlIFRoaXMgUGFnZScsJ21vZHVsZXMvdHJhbnNsYXRlL2luZGV4LnBocCcsJ19wb3B1cCcsJzI4MCcsJzMwMCcsJycsJzEnKTs';