<?php
$trayiconinfo = array('twitter','Twitter');
$trayicondata = 'JHRyYXlpY29uW10gPSBhcnJheSgndHdpdHRlcicsJ1R3aXR0ZXInLCdtb2R1bGVzL3R3aXR0ZXIvaW5kZXgucGhwJywnX3BvcHVwJywnNTAwJywnMzAwJywnJywnMScpOw';