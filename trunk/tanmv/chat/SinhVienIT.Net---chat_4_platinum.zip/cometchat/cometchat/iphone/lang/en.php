<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$iphone_language[0] = 'Chat';
$iphone_language[1] = 'Users Online for Chat';
$iphone_language[2] = 'X';
$iphone_language[3] = 'Lobby';
$iphone_language[4] = 'No users online at the moment.';
$iphone_language[5] = 'Sorry you have logged out';
$iphone_language[6] = 'Me';
$iphone_language[7] = ':  ';
$iphone_language[8] = 'X';
$iphone_language[9] = 'Type your message';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////