<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* LANGUAGE */

$jabber_language[0] = 'Connect to Facebook/Gtalk chat';
$jabber_language[1] = 'Who would you like to chat with?';
$jabber_language[2] = 'Email:';
$jabber_language[3] = 'Password:';
$jabber_language[4] = 'Google Talk';
$jabber_language[5] = 'Facebook';
$jabber_language[6] = 'Signin to Google Talk';
$jabber_language[7] = 'Processing login...';
$jabber_language[8] = 'Logout from Facebook';
$jabber_language[9] = 'Incorrect login details. Please try again.';
$jabber_language[10] = 'Site Users';
$jabber_language[11] = 'Facebook Friends';
$jabber_language[12] = 'Gtalk Friends';
$jabber_language[13] = 'Logout from Gtalk';
$jabber_language[14] = 'No users online at the moment.';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////