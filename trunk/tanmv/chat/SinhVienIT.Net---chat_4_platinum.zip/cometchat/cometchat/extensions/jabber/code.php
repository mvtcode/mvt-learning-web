<?php
$extensioninfo = array('jabber','Facebook/Gtalk Chat');